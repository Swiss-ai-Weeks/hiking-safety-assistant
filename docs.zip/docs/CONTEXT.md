# Hiking Safety Assistant — Domain Glossary

Terms resolved during the 2026-09-14 architecture grill. Glossary only; no implementation detail.

## Moment
One of the three user situations the assistant serves: **pre-hike planning**, **in-situ support** (on the route), and **risk identification with alternatives**. A moment is a product scope unit, not a system component.

## Vertical slice
The subset of moments, clients, data sources, and response languages the hackathon team commits to building end to end. Resolved 2026-09-14: planning and alternatives, web client only, official-network routes, MeteoSwiss OGD only, response languages EN and DE. In-situ, phone, watch, GPX and region input, meteoblue, and FR/IT responses are designed but deferred.

## Decision support
The assistant's positioning: it surfaces conditions, risks, and considerations and never issues a safe/go verdict. Contrast with **authority**, which the official Swiss channels (MeteoSwiss warnings, avalanche bulletin, 1414/112) retain.

## Safety invariant
A named, testable rule that every released assessment must satisfy (for example: a recommendation must link to the hazard that justifies it; an official warning outranks any derived hazard in its category). Resolved 2026-09-14: invariants are executable code, not ontology constraints. Structural invariants are **fusion post-conditions**; framing invariants are enforced by the **output gate**.

## Fusion post-condition
A safety invariant checked inside the fusion engine before an assessment is emitted. A failure is either **repaired** (the offending element is removed or subordinated: an unjustified recommendation is dropped, a derived hazard is subordinated to an official warning) or **fatal** (the assessment is not produced and the outcome is *not assessable*: an assessment with a hazard lacking linked evidence).

## Output gate
The deterministic, two-stage check that stands between fusion output and the user. **Stage 1** runs on the structured assessment before rendering and sets framing: stale inputs lower confidence, low confidence forces cautionary framing. **Stage 2** runs on the assembled conversational wrapper before release: every sentence must resolve to an identifier in the approved **wrapper phrase bank**; anything else is rejected, not hedged. The phrase bank is reviewed against the safe/go verdict patterns and the controlled safety vocabulary when it changes. Rendered sentences and cited excerpts do not pass through stage 2 because their content is fixed by construction.

## Assessment outcome
One of three mutually exclusive results of a planning query, by rule-evaluation coverage: **assessed** (every applicable hazard rule evaluated on every segment), **partially assessed** (at least one applicable rule on at least one segment could not be evaluated for lack of an input; affected segments are marked *not evaluated*), **not assessable** (weather unavailable, route unresolved, or a fatal post-condition). Precedence: not assessable, then partially assessed, then assessed. An empty hazard list is meaningful only under *assessed*.

## Ontology (OWL)
The design-time shared vocabulary for the static plane and the provenance model. Resolved 2026-09-14: OWL is authored at design time only; the runtime store is a property graph or typed objects with spatial queries. GeoSPARQL and SHACL are not runtime capabilities.

## Response text
The user-facing text of a response, made of three kinds of sentence. **Rendered sentences** are produced deterministically from fusion objects and static-plane attributes through **explanation templates**. **Cited excerpts** are verbatim passages from the retrieval corpus shown with source and timestamp. The **conversational wrapper** is assembled from an approved, slot-free **phrase bank** (acknowledgement, orientation, transitions, follow-up offers); the LLM selects and orders phrase identifiers and never emits free prose to the user. The LLM never generates, paraphrases, or translates a factual sentence. Resolved 2026-09-14, user-confirmed after Codex Round 4. The word *narration* is retired; use the three terms above.

## Explanation template
A per-language text pattern that states one relationship in fixed words and exposes typed value slots (condition, threshold, segment, time window, attribute value). One template per hazard rule and per rendered route attribute, authored and reviewed by people. **Template coverage** for a language is complete when every rule and attribute has a reviewed template; a language is enabled only when its coverage is complete. If a safety object cannot be rendered in the response language at runtime, the safety blocks fall back to the reference language (EN) with a notice; a detected hazard is never dropped for lack of a template.

## Mitigation and alternative
A **mitigation** is a change to the same route's plan (earlier start, turnaround point) that fusion re-evaluation shows removes or lowers the triggering hazard. An **alternative** is a different official-network route, with its own traversal plan and weather snapshot, whose independent assessment shows the same. Neither is offered unless the re-assessment supports it.

## Weather source
Resolved 2026-09-14: MeteoSwiss Open Government Data (OGD) is the only weather source in scope, matching DR-1 and the open-data constraint. meteoblue is considered and deferred. **Confidence** on a weather condition derives from MeteoSwiss forecast lead time, warning level, and data age, not from a third-party predictability index.

## Route and Segment
A **route** is a hike resolved against the swisstopo official hiking network. A **segment** is the unit of the risk-fusion spine: a stretch of route with terrain attributes and an expected traversal time window. Resolved 2026-09-14: the slice accepts a route by name or by start/end points on the official network; segments are precomputed for network routes. GPX upload and region search are deferred. The documented future path for ad-hoc tracks is direct segmentation by distance and elevation change with terrain sampled along the track, without map-matching.

## Weather snapshot
The timestamped set of MeteoSwiss conditions covering one route geometry and its traversal time windows, keyed by route, hike date, and forecast window, and held with a short time-to-live. Follow-up questions reuse it only while the key matches and the TTL holds; a change of route, date, start time, or pace invalidates it and triggers a fresh fetch and reassessment. Each alternative candidate route has its own snapshot. It is never persisted as a durable fact. Distinct from the **materialised offline snapshot**, which is the bounded bundle compiled for a device before it goes offline (deferred with the in-situ moment).

## Latency target
Resolved 2026-09-14: the structured assessment is returned within about five seconds of a planning query and rendered immediately; cited excerpts and the assembled wrapper follow as blocks.

## Source fact and derived fact
A **source fact** is an assertion taken from swisstopo or MeteoSwiss and carries provenance: source, timestamp, confidence, freshness. A **derived fact** (hazard, risk assessment, recommendation) is computed by the fusion engine and carries derived provenance: the input fact IDs, the **hazard rule** ID and version that fired, and the computed confidence. The user-facing explanation is generated from this record.

## Hazard rule
A versioned, deterministic rule in the team-owned rule catalogue that maps a combination of segment terrain, weather condition, and timing to a hazard. Each rule has an ID, a version, a one-line justification, and a cited basis (for example SAC guidance or MeteoSwiss warning criteria). Rules are authored by people, never generated at runtime.
