"""Assessment pipeline behind the screens (ARCHITECTURE §4, §6, §8). Builds the view model the templates render.

Demo mode: fixture route + a deterministic demo weather field shaped like the UI spec scenario.
Live mode (HSA_LIVE=1): swisstopo + MeteoSwiss adapters.
"""
from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

from hsa.adapters.interfaces import RouteSource, Unresolved
from hsa.adapters.warnings import UnavailableWarnings, WarningsSource
from hsa.domain.models import HikePlan, Route, Severity, Unknown, WeatherCondition
from hsa.domain.outcome import Outcome, classify
from hsa.domain.provenance import SourceProvenance
from hsa.fusion.alternatives import propose
from hsa.fusion.engine import FusionEngine
from hsa.fusion.post_conditions import apply_post_conditions
from hsa.gate.i18n import CHROME
from hsa.gate.phrase_bank import PhraseBank
from hsa.gate.renderer import Renderer, load_rec_templates
from hsa.gate.stage1 import apply_stage1
from hsa.gate.stage2 import DISCLAIMER
from hsa.geo.traversal import traversal_windows
from hsa.rules.loader import load_catalogue
from hsa.weather.snapshot import SnapshotKey, SnapshotStore, WeatherSnapshot

ROOT = Path(__file__).resolve().parents[3]
ZURICH = ZoneInfo("Europe/Zurich")


def local_start(date: str, start: str) -> datetime:
    """Hike plans are entered in Swiss local time; forecasts are UTC. Aware datetimes carry the difference."""
    return datetime.fromisoformat(f"{date}T{start}:00").replace(tzinfo=ZURICH)


SEV_CLASS = {"none": "sev-none", "moderate": "sev-moderate", "high": "sev-high"}


def _hhmm(t: datetime) -> str:
    return t.astimezone(ZURICH).strftime("%H:%M")


class DemoWeather:
    """Deterministic field shaped like the UI spec: ridge gusts build after 11:00, showers from 13:00, cold aloft."""

    def __init__(self, run_time: datetime):
        self.run_time = run_time

    def __call__(self, route: Route, plan: HikePlan) -> WeatherSnapshot | None:
        wins = traversal_windows(route.segments, plan.start_time, plan.pace_factor)
        conds: list[WeatherCondition] = []
        for seg, w in zip(route.segments, wins):
            t = w.start.replace(minute=0, second=0, microsecond=0)
            while t <= w.end:
                lh = t.astimezone(ZURICH).hour
                ridge = seg.elevation_max_m >= 2600
                gust = (55.0 if 13 <= lh < 16 else 35.0 if lh >= 16 else 22.0) if ridge else (18.0 if lh < 12 else 26.0)
                precip = 1.6 if lh >= 13 else 0.0
                temp = -2.0 if ridge else 9.0 - seg.elevation_max_m / 400
                conds.append(WeatherCondition(id=f"wc:{seg.index}:{t:%Y%m%dT%H}", segment_id=seg.id, valid_at=t,
                                              temperature_c=round(temp, 1), gust_kmh=gust, precipitation_mm=precip,
                                              cloud_base_m=3200.0, freezing_level_m=2900.0, cape_jkg=150.0,
                                              provenance=SourceProvenance(source="demo:icon-ch1-shaped", observed_at=self.run_time, confidence=0.85)))
                t += timedelta(hours=1)
        key = SnapshotKey(route_id=route.id, hike_date=plan.start_time.date(), start_hour=plan.start_time.hour,
                          pace_factor=plan.pace_factor, forecast_window="ch1")
        return WeatherSnapshot(key=key, fetched_at=self.run_time + timedelta(minutes=40), run_time=self.run_time, conditions=conds, source="demo")


class Pipeline:
    def __init__(self, routes: RouteSource, weather, warnings: WarningsSource, now: datetime | None = None):
        self.routes, self.weather, self.warnings = routes, weather, warnings
        self.now = now
        self.cat = load_catalogue(ROOT / "src/hsa/rules/rules", ROOT / "templates")
        self.engine = FusionEngine(self.cat)
        self.renderer = Renderer(self.cat, load_rec_templates(ROOT / "templates"))
        self.bank = PhraseBank.load(ROOT / "phrasebank")
        self.snapshots = SnapshotStore()

    # ------------------------------------------------------------------ public
    def assess(self, route_query: str, date: str, start: str, lang: str = "en", pace_factor: float = 1.25,
               capability: int | None = None, mode_label: str = "demo") -> dict:
        lang = lang if lang in CHROME else "en"
        c = CHROME[lang]
        now = self.now or datetime.now(timezone.utc)
        route = self.routes.resolve_by_name(route_query)
        start_dt = local_start(date, start)
        base = {"lang": lang, "c": c, "query": {"route": route_query, "date": date, "start": start, "lang": lang},
                "channels": [{"label": "MeteoSwiss forecast", "href": "https://www.meteoswiss.admin.ch"},
                             {"label": "SLF avalanche bulletin", "href": "https://www.slf.ch"}],
                "disclaimer": DISCLAIMER.get(lang, DISCLAIMER["en"]), "mode": mode_label}
        if isinstance(route, Unresolved):
            cl = classify(route, HikePlan(route_id="?", date=start_dt, start_time=start_dt), None, None, None)
            return {**base, "outcome": "not_assessable", "reason": cl.reason, "checked_at": _hhmm(now),
                    "route": {"name": route_query, "grade": "?", "distance_km": "?", "ascent_m": 0, "date_label": start_dt.strftime("%a %d %b"), "start": start},
                    "route_resolved": False}
        plan = HikePlan(route_id=route.id, date=start_dt, start_time=start_dt, pace_factor=pace_factor, capability_grade=capability)
        route_view = {"name": route.name, "grade": route.grade.label() if not isinstance(route.grade, Unknown) else "T?",
                      "distance_km": round(route.length_m / 1000, 1), "ascent_m": round(route.ascent_m),
                      "date_label": start_dt.strftime("%a %d %b"), "start": start}
        snap = self.weather(route, plan)
        if snap is None:
            cl = classify(route, plan, None, None, None)
            return {**base, "outcome": "not_assessable", "reason": cl.reason, "checked_at": _hhmm(now), "route": route_view, "route_resolved": True}
        warnings = self.warnings.fetch(region="CH")
        res = self.engine.assess(route, plan, snap, warnings, now)
        props = propose(res, route, plan, self.engine, self.weather, candidates=self.routes.candidates_near(route.coords[0], 5000, 3), now=now)
        props.recommendations = [r for r in props.recommendations if not (r.kind == "alternative" and r.slots.get("route_id") == route.id)]
        pc = apply_post_conditions(res.assessment, props.recommendations, warnings, known_fact_ids={x.id for x in snap.conditions} | {s.id for s in route.segments} | {res.assessment.id, *[h.id for h in res.assessment.hazards]})
        cl = classify(route, plan, res, snap, pc.fatal)
        if cl.outcome == Outcome.NOT_ASSESSABLE:
            return {**base, "outcome": "not_assessable", "reason": cl.reason, "checked_at": _hhmm(now), "route": route_view, "route_resolved": True}
        framed = apply_stage1(pc.assessment, snap, now)
        a = framed.assessment
        return {**base, **self._view(route, plan, snap, res, a, cl, framed, pc, props, lang, now), "route": route_view, "route_resolved": True}

    # ------------------------------------------------------------------ view
    def _view(self, route, plan, snap, res, a, cl, framed, pc, props, lang, now) -> dict:
        c = CHROME[lang]
        wins = res.windows
        by_seg_h = {s.id: [h for h in a.hazards if h.segment_id == s.id] for s in route.segments}
        seg_sev = {s.id: max((h.severity for h in by_seg_h[s.id]), key=lambda x: x.rank, default=Severity.NONE) for s in route.segments}
        cond_by_seg: dict[str, list[WeatherCondition]] = {}
        for wc in snap.conditions:
            cond_by_seg.setdefault(wc.segment_id, []).append(wc)

        def in_window(seg):
            st, en = wins[seg.id]
            return [x for x in cond_by_seg.get(seg.id, []) if st.replace(minute=0) <= x.valid_at <= en]

        def gust_max(seg):
            vals = [x.gust_kmh for x in in_window(seg) if not isinstance(x.gust_kmh, Unknown)]
            return max(vals) if vals else 0.0

        # crux: segment with worst hazard, else highest point
        crux_seg = max(route.segments, key=lambda s: (seg_sev[s.id].rank, s.elevation_max_m))
        crux_conds = in_window(crux_seg)
        peak = max(crux_conds, key=lambda x: x.gust_kmh if not isinstance(x.gust_kmh, Unknown) else 0) if crux_conds else None
        first_rain = next((x for s in route.segments for x in in_window(s) if not isinstance(x.precipitation_mm, Unknown) and x.precipitation_mm >= 1.0), None)
        crux_name = crux_seg.place or (crux_seg.name.split('→')[-1].strip() if '→' in crux_seg.name else f"Leg {crux_seg.index + 1} high point")
        crux_elev = crux_seg.place_elevation_m or crux_seg.elevation_max_m
        crux = {"place": f"{crux_name}, {format(round(crux_elev), ',').replace(',', ' ')} m",
                "eta": _hhmm(wins[crux_seg.id][0] + (wins[crux_seg.id][1] - wins[crux_seg.id][0]) / 2),
                "tiles": [{"label": c["gusts"], "value": f"{round(peak.gust_kmh)} km/h" if peak and not isinstance(peak.gust_kmh, Unknown) else "?", "accent": True},
                          {"label": c["feels"], "value": f"{round(peak.temperature_c - (peak.gust_kmh or 0) / 10)}°" if peak and not isinstance(peak.temperature_c, Unknown) and not isinstance(peak.gust_kmh, Unknown) else "?"},
                          {"label": c["showers"], "value": _hhmm(first_rain.valid_at) if first_rain else c["none"]}],
                "stale": a.stale}
        gmax = max((gust_max(s) for s in route.segments), default=1.0) or 1.0
        timeline = []
        for s in route.segments:
            st, en = wins[s.id]
            timeline.append({"time": _hhmm(st), "place": s.name.split("→")[0].strip().replace("Segment ", "Leg "), "pct": max(12, round(100 * gust_max(s) / gmax)),
                             "sev": seg_sev[s.id].value, "crux": s.id == crux_seg.id, "window": f"{_hhmm(st)}–{_hhmm(en)}",
                             "name": s.name, "grade": s.grade.label() if not isinstance(s.grade, Unknown) else "T?",
                             "coords": s.coords, "note": ", ".join(self.renderer.render_hazard(h, lang).title for h in by_seg_h[s.id]) or f"nothing flagged as of {_hhmm(snap.run_time)}"})
        timeline.append({"time": _hhmm(wins[route.segments[-1].id][1]), "place": ("End" if "→" not in route.segments[-1].name else route.segments[-1].name.split("→")[-1].strip()), "pct": 12, "sev": "none", "crux": False, "end": True})
        hazards = []
        for h in sorted(a.hazards, key=lambda x: (-x.severity.rank, x.window_start)):
            rs = self.renderer.render_hazard(h, lang)
            hazards.append({"sev": h.severity.value, "title": rs.title, "body": rs.body, "provenance": rs.provenance,
                            "fallback_notice": rs.fallback_notice, "subordinated": h.subordinated_to_warning, "id": h.id})
        unflagged = [s.name for s in route.segments if not by_seg_h[s.id]]
        nothing = None
        if cl.show_nothing_flagged and unflagged:
            nothing = (f"Nothing flagged on {', '.join(unflagged)} given data as of {_hhmm(snap.run_time)}." if lang == "en"
                       else f"Nichts markiert auf {', '.join(unflagged)} nach Datenstand {_hhmm(snap.run_time)}.")
        cannot_see = list(pc.disclosures)
        if framed.stale_label:
            cannot_see.append(f"Forecast is {framed.stale_label}." if lang == "en" else f"Prognose ist {framed.stale_label}.")
        cannot_see += [f"{x}: not available from the source." for x in cl.not_available[:3]]
        if cl.assumed_capability_note:
            cannot_see.append(cl.assumed_capability_note)
        grouped: dict[str, dict] = {}
        for seg_id, rule, missing in cl.not_evaluated:
            name = next(s.name for s in route.segments if s.id == seg_id)
            g = grouped.setdefault(seg_id, {"segment": name, "rules": [], "missing": []})
            g["rules"].append(rule)
            g["missing"] = sorted(set(g["missing"]) | set(missing))
        not_evaluated = list(grouped.values())
        mitigations, alternatives = [], []
        for r in a.recommendations:
            rs = self.renderer.render_recommendation(r, lang)
            item = {"title": rs.title, "body": rs.body, "provenance": rs.provenance, "rule_id": r.provenance.rule_id, "slots": r.slots,
                    "tag": c["suggested"] if r.provenance.rule_id == "MIT-START-01" else (r.slots.get("grade", "") if r.kind == "alternative" else ""),
                    "primary": r.provenance.rule_id == "MIT-START-01"}
            (alternatives if r.kind == "alternative" else mitigations).append(item)
        turn = next((r for r in a.recommendations if r.provenance.rule_id == "MIT-TURN-01"), None)
        shift = next((r for r in a.recommendations if r.provenance.rule_id == "MIT-START-01"), None)
        plan_view = {"start": shift.slots["new_start"] if shift else _hhmm(plan.start_time),
                     "start_note": f"(moved from {shift.slots['old_start']})" if shift else "",
                     "turnaround_time": turn.slots["turn_by"] if turn else "", "turn_place": turn.slots["turn_place"] if turn else "",
                     "turnaround": self.renderer.render_recommendation(turn, lang).body if turn else "",
                     "party": 1, "why": mitigations[0]["body"] if mitigations else ""}
        outcome_label = {Outcome.ASSESSED: c["assessed"], Outcome.PARTIALLY_ASSESSED: c["partial"]}[cl.outcome]
        return {"outcome": cl.outcome.value, "outcome_label": outcome_label, "outcome_class": "" if cl.outcome == Outcome.ASSESSED else "amber",
                "forecast_time": _hhmm(snap.run_time), "stale_label": framed.stale_label, "cautionary": a.cautionary,
                "crux": crux, "timeline": timeline, "hazards": hazards, "nothing_flagged": nothing, "cannot_see": cannot_see,
                "not_evaluated": not_evaluated, "mitigations": mitigations, "alternatives": alternatives, "none_found": props.none_found_reason,
                "plan": plan_view, "segments": [t for t in timeline if not t.get("end")],
                "crux_coord": list(crux_seg.coords[len(crux_seg.coords) // 2]),
                "turnaround_coord": list(next((s for s in route.segments if (s.place or s.name) == plan_view["turn_place"]), route.segments[0]).coords[-1]),
                "confidence": a.confidence, "repairs": pc.repairs, "trace": a.reasoning_trace,
                "field": {"clock": _hhmm(wins[crux_seg.id][0] - timedelta(minutes=48)), "plan_from": _hhmm(snap.fetched_at),
                          "next": f"Next: {crux_name} · {round(crux_seg.length_m/1000,1)} km · ↑{round(crux_seg.ascent_m)} m",
                          "eta_col": _hhmm(wins[crux_seg.id][1] - timedelta(minutes=25)), "rule_short": plan_view["turnaround"]},
                "share": {"made": f"Made {now:%d %b %H:%M} from MeteoSwiss ({_hhmm(snap.run_time)} run) and swisstopo.",
                          "watch_for": " ".join(h["title"] + "." for h in hazards[:2]),
                          "not_checked": "; ".join(x.rstrip(".") for x in cannot_see[:2])}}


def demo_pipeline(now: datetime | None = None) -> Pipeline:
    from tests.fakes.swisstopo import FakeSwisstopo  # fixture route lives with the tests on purpose: it is not a data source

    run = datetime(2026, 9, 19, 6, 0, tzinfo=ZURICH)  # 06:00 local run label, as in the UI spec
    return Pipeline(FakeSwisstopo(), DemoWeather(run), UnavailableWarnings(), now=now or run + timedelta(minutes=45))


def live_pipeline() -> Pipeline:
    from hsa.adapters.meteoswiss import MeteoSwissClient
    from hsa.adapters.swisstopo import SwisstopoClient

    ms = MeteoSwissClient()

    def weather(route: Route, plan: HikePlan):
        wins = traversal_windows(route.segments, plan.start_time, plan.pace_factor)
        hours = sorted({w.start.replace(minute=0, second=0, microsecond=0) + timedelta(hours=k) for w in wins
                        for k in range(int((w.end - w.start).total_seconds() // 3600) + 2)})
        key = SnapshotKey(route_id=route.id, hike_date=plan.start_time.date(), start_hour=plan.start_time.hour, pace_factor=plan.pace_factor, forecast_window="auto")
        return ms.fetch_snapshot(route.segments, key, hours)

    return Pipeline(SwisstopoClient(), weather, UnavailableWarnings())


def default_pipeline() -> Pipeline:
    return live_pipeline() if os.environ.get("HSA_LIVE") == "1" else demo_pipeline()
