from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from markupsafe import Markup

from hsa.api.fixture import SEV, demo_scenario
from hsa.api.pipeline import default_pipeline

HERE = Path(__file__).parent
app = FastAPI(title="Hiking Safety Assistant")
app.mount("/static", StaticFiles(directory=HERE / "static"), name="static")
templates = Jinja2Templates(directory=HERE / "templates")
templates.env.globals["SEV"] = SEV

DEFAULT_ROUTE = "Oeschinensee → Blüemlisalphütte"


@lru_cache(maxsize=1)
def pipeline():
    return default_pipeline()


def _safe(c: dict) -> dict:
    return {k: Markup(v) for k, v in c.items()}


def _render(request: Request, name: str, **ctx) -> HTMLResponse:
    if "c" in ctx:
        ctx["c"] = _safe(ctx["c"])
    return templates.TemplateResponse(request, name, ctx)


def _assess(route: str | None, date: str | None, start: str | None, lang: str, outcome: str | None = None) -> dict:
    if outcome == "not_assessable":  # spec screen 02b on demand
        route = "Nowhere Ridge"
    view = pipeline().assess(route or DEFAULT_ROUTE, date or "2026-09-19", start or "07:30", lang=lang,
                             mode_label="live" if os.environ.get("HSA_LIVE") == "1" else "demo")
    view["recent"] = demo_scenario()["recent"]
    return view


@app.get("/", response_class=HTMLResponse)
def plan(request: Request, lang: str = "en"):
    s = demo_scenario(); s["lang"] = lang
    from hsa.gate.i18n import CHROME
    return _render(request, "plan.html", s=s, c=CHROME.get(lang, CHROME["en"]), default_route=DEFAULT_ROUTE)


@app.get("/assess", response_class=HTMLResponse)
def assess(request: Request, route: str | None = None, date: str | None = None, start: str | None = None,
           lang: str = "en", outcome: str | None = None):
    s = _assess(route, date, start, lang, outcome)
    tpl = "not_assessable.html" if s["outcome"] == "not_assessable" else "assess.html"
    return _render(request, tpl, s=s, c=s["c"])


@app.get("/map", response_class=HTMLResponse)
def route_map(request: Request, route: str | None = None, date: str | None = None, start: str | None = None, lang: str = "en"):
    s = _assess(route, date, start, lang)
    return _render(request, "map.html", s=s, c=s["c"])


@app.get("/preflight", response_class=HTMLResponse)
def preflight(request: Request, route: str | None = None, date: str | None = None, start: str | None = None, lang: str = "en"):
    s = _assess(route, date, start, lang)
    return _render(request, "preflight.html", s=s, c=s["c"])


@app.get("/field", response_class=HTMLResponse)
def field(request: Request, route: str | None = None, date: str | None = None, start: str | None = None, lang: str = "en"):
    s = _assess(route, date, start, lang)
    return _render(request, "field.html", s=s, c=s["c"])


@app.get("/share", response_class=HTMLResponse)
def share(request: Request, route: str | None = None, date: str | None = None, start: str | None = None, lang: str = "en"):
    s = _assess(route, date, start, lang)
    return _render(request, "share.html", s=s, c=s["c"])
