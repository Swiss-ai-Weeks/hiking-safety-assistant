"""Demo scenario used by the screens until the fusion pipeline is wired in (U1).

Every sentence here mirrors a template-rendered sentence in the UI spec mock-up. When the
backend batches land, /assess is fed by the real view model with the same shape.
"""
from __future__ import annotations

SEV = {"none": "sev-none", "moderate": "sev-moderate", "high": "sev-high"}


def demo_scenario(outcome: str = "assessed") -> dict:
    route = {
        "name": "Oeschinensee → Blüemlisalphütte",
        "grade": "T3",
        "distance_km": 11.2,
        "ascent_m": 1220,
        "date_label": "Sat 19 Sep",
        "start": "07:30",
    }
    base = {
        "route": route,
        "forecast_time": "06:40",
        "outcome": outcome,
        "lang": "en",
        "channels": [
            {"label": "MeteoSwiss forecast", "href": "https://www.meteoswiss.admin.ch"},
            {"label": "SLF avalanche bulletin", "href": "https://www.slf.ch"},
        ],
        "recent": [
            {"name": "Schynige Platte → Faulhorn", "meta": "T2 · checked 6 Sep"},
            {"name": "Gemmipass", "meta": "T2 · checked 30 Aug"},
        ],
    }
    if outcome == "not_assessable":
        base.update(
            {
                "checked_at": "08:12",
                "reason": (
                    "The MeteoSwiss forecast for this area has been unavailable since 05:10. "
                    "Without it we won't show hazards or recommendations, because an empty "
                    "list could read as reassurance."
                ),
                "hut_phone": "Blüemlisalphütte · +41 33 676 14 37",
            }
        )
        return base
    base.update(
        {
            "crux": {
                "place": "Hohtürli, 2 778 m",
                "eta": "11:40",
                "tiles": [
                    {"label": "Gusts", "value": "55 km/h", "accent": True},
                    {"label": "Feels like", "value": "−2°"},
                    {"label": "Showers", "value": "13:00"},
                ],
            },
            "timeline": [
                {"time": "07:30", "place": "Lake", "pct": 18, "sev": "none"},
                {"time": "09:30", "place": "Oberbärgli", "pct": 30, "sev": "none"},
                {"time": "10:40", "place": "Moraine", "pct": 55, "sev": "moderate"},
                {"time": "11:40", "place": "Hohtürli", "pct": 100, "sev": "high", "crux": True},
                {"time": "12:00", "place": "Hütte", "pct": 85, "sev": "high"},
                {"time": "13:30", "place": "Descent", "pct": 60, "sev": "moderate"},
                {"time": "16:00", "place": "Lake", "pct": 35, "sev": "none"},
            ],
            "timeline_note": "Times assume a cautious pace until you tell us yours. Descent included.",
            "hazards": [
                {
                    "sev": "high",
                    "title": "Strong gusts on the Hohtürli ridge, 11:00–14:00",
                    "body": (
                        "Gusts of 50–60 km/h on an exposed T3 section with fixed cables. "
                        "Reaching the col before 11:00 keeps you below 40 km/h."
                    ),
                    "lifts_if": "the 09:00 forecast update shows gusts under 40 km/h at 2 800 m.",
                    "provenance": "Rule WIND-EXP-02 v3 · SAC guidance · ICON-CH1 06:40",
                },
                {
                    "sev": "moderate",
                    "title": "Showers on the descent from 13:00",
                    "body": (
                        "Wet rock on the steep moraine path between Hütte and Oberbärgli, taken "
                        "tired. Freezing level 2 900 m, so rain, not snow."
                    ),
                    "provenance": "Rule PRECIP-DESC-01 v2 · ICON-CH1 06:40",
                },
            ],
            "nothing_flagged": "Nothing flagged on Lake → Oberbärgli given data as of 06:40.",
            "cannot_see": [
                "Official weather warnings could not be checked. Check MeteoSwiss yourself.",
                "No snow-line observation for the north side of the col.",
                "Your pace. We're assuming a cautious default until you tell us.",
            ],
            "mitigations": [
                {
                    "title": "Start at 06:30 instead",
                    "tag": "Suggested",
                    "body": (
                        "Puts you on Hohtürli at 10:40, before the gusts build. You keep the hut "
                        "lunch and the 16:10 last boat."
                    ),
                    "primary": True,
                }
            ],
            "alternatives": [
                {
                    "title": "Or: Oeschinensee high loop, T2",
                    "tag": "4 h 10",
                    "body": (
                        "Same lake, same view, no ridge. Nothing flagged for Saturday on this "
                        "route as of 06:40."
                    ),
                }
            ],
            "segments": [
                {"name": "Oeschinensee → Oberbärgli", "window": "06:30–08:40", "grade": "T2",
                 "note": "nothing flagged as of 06:40", "sev": "none",
                 "coords": [[46.4985, 7.7275], [46.4930, 7.7380], [46.4880, 7.7470]]},
                {"name": "Oberbärgli → Moraine", "window": "08:40–10:20", "grade": "T3",
                 "note": "wet rock on return from 13:00", "sev": "moderate",
                 "coords": [[46.4880, 7.7470], [46.4890, 7.7580], [46.4915, 7.7660]]},
                {"name": "Moraine → Hohtürli → Hütte", "window": "10:20–11:40", "grade": "T3, cables",
                 "note": "gusts 50–60 km/h from 11:00", "sev": "high",
                 "coords": [[46.4915, 7.7660], [46.4940, 7.7740], [46.4935, 7.7755]]},
            ],
            "crux_coord": [46.4940, 7.7740],
            "turnaround_coord": [46.4915, 7.7660],
            "plan": {
                "start": "06:30",
                "start_note": "(moved from 07:30)",
                "turnaround": "If not at Hohtürli by 11:30, or cloud base is below the ridge, descend via Oberbärgli.",
                "turnaround_time": "11:30",
                "why": (
                    "Crosses the ridge before the gusts build and keeps the 16:10 last boat. "
                    "Pushing on past 11:30 costs the boat and the easy descent."
                ),
                "recompute_note": "Plan recomputed with your pace. Hohtürli now around 11:20; descent back at the lake around 15:40.",
                "party": 4,
            },
            "field": {
                "clock": "10:52",
                "plan_from": "06:12",
                "next": "Next: Hohtürli · 1.1 km · ↑310 m",
                "headline": "You're ahead of your turnaround.",
                "eta_col": "11:15",
                "rule_short": "If not at Hohtürli by 11:30, or cloud base below the ridge → descend via Oberbärgli.",
                "observation": {
                    "question": "Quick look up: where's the cloud base?",
                    "options": ["Above the ridge, clear", "Touching the ridge",
                                "Below the ridge → your rule says turn"],
                },
            },
            "share": {
                "made": "Made 18 Sep 21:40 from MeteoSwiss ICON-CH1 (06:40) and swisstopo.",
                "watch_for": "Gusts on the ridge after 11:00. Wet rock on the moraine descent from 13:00.",
                "not_checked": "Official warnings, snow line north of the col.",
            },
        }
    )
    return base
