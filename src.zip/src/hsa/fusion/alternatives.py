"""Mitigations first, then alternatives (ARCHITECTURE §8). Nothing is offered unless a re-assessment supports it."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Callable

from hsa.domain.models import GradeRange, HikePlan, Recommendation, Route, Severity, Unknown
from hsa.domain.provenance import DerivedProvenance
from hsa.fusion import config
from hsa.fusion.engine import FusionEngine, FusionResult
from hsa.weather.snapshot import WeatherSnapshot
from hsa.fusion.engine import ZURICH

WeatherProvider = Callable[[Route, HikePlan], WeatherSnapshot | None]
NONE_FOUND = ("No supported mitigation or alternative was found for these conditions. "
              "Check MeteoSwiss and the SLF bulletin directly before deciding.")


@dataclass
class Proposals:
    recommendations: list[Recommendation] = field(default_factory=list)
    ineligible: list[str] = field(default_factory=list)
    none_found_reason: str | None = None
    trace: list[str] = field(default_factory=list)


def _worst(res: FusionResult) -> Severity:
    return res.assessment.severity


def eligibility_limit(route: Route, plan: HikePlan) -> int | None:
    """Scalar L: plan grade upper bound, lowered to stated capability. None if plan grade unknown."""
    if isinstance(route.grade, Unknown) or route.grade is None:
        return None
    upper = route.grade.high
    return min(upper, plan.capability_grade) if plan.capability_grade else upper


def _improves(base: FusionResult, trial: FusionResult, trigger_id: str) -> bool:
    """Triggering hazard removed or lowered, without adding a hazard of equal or higher severity."""
    base_h = {h.id: h for h in base.assessment.hazards}
    trig = base_h[trigger_id]
    trial_ids = {h.id: h for h in trial.assessment.hazards}
    still = trial_ids.get(trigger_id)
    lowered = still is None or still.severity.rank < trig.severity.rank
    if not lowered:
        return False
    for hid, h in trial_ids.items():
        if hid not in base_h and h.severity.rank >= trig.severity.rank:
            return False
    return True


def propose(base: FusionResult, route: Route, plan: HikePlan, engine: FusionEngine, weather: WeatherProvider,
            candidates: list[Route], now: datetime) -> Proposals:
    out = Proposals()
    threshold = Severity(config.SEVERITY_THRESHOLD).rank
    triggers = [h for h in base.assessment.hazards if h.severity.rank >= threshold]
    if not triggers:
        return out
    trigger = max(triggers, key=lambda h: h.severity.rank)
    # 1. timing mitigations: earlier start
    for shift in config.START_SHIFTS_HOURS:
        p2 = plan.model_copy(update={"start_time": plan.start_time + timedelta(hours=shift)})
        snap = weather(route, p2)
        if snap is None:
            continue
        trial = engine.assess(route, p2, snap, base.warnings, now)
        if _improves(base, trial, trigger.id):
            out.recommendations.append(Recommendation(
                id=f"rec:start:{shift}", kind="mitigation", justifies=[trigger.id],
                slots={"new_start": p2.start_time.astimezone(ZURICH).strftime("%H:%M"), "old_start": plan.start_time.astimezone(ZURICH).strftime("%H:%M"),
                       "place": trigger.slots.get("place", ""), "shift_h": abs(shift)},
                provenance=DerivedProvenance(input_fact_ids=[trigger.id, trial.assessment.id], rule_id="MIT-START-01",
                                             rule_version=1, confidence=trial.assessment.confidence)))
            out.trace.append(f"MIT-START-01: start {p2.start_time:%H:%M} removes/lowers {trigger.id}")
            break
        out.trace.append(f"MIT-START-01: start {p2.start_time:%H:%M} does not improve {trigger.id}")
    # 2. turnaround before the triggering segment (always assessable: the hazard is not reached)
    seg_idx = next((s.index for s in route.segments if s.id == trigger.segment_id), None)
    if seg_idx is not None and seg_idx > 0:
        before = route.segments[seg_idx - 1]
        w = base.windows[before.id]
        out.recommendations.append(Recommendation(
            id="rec:turnaround", kind="mitigation", justifies=[trigger.id],
            slots={"turn_place": before.place or before.name, "turn_by": w[1].astimezone(ZURICH).strftime("%H:%M"), "place": trigger.slots.get("place", "")},
            provenance=DerivedProvenance(input_fact_ids=[trigger.id, before.id], rule_id="MIT-TURN-01", rule_version=1,
                                         confidence=base.assessment.confidence)))
    # 3. alternatives
    limit = eligibility_limit(route, plan)
    if limit is None:
        out.ineligible.append("plan grade unknown: automatic alternatives withheld")
    else:
        for cand in candidates[: config.CANDIDATE_LIMIT_N]:
            if isinstance(cand.grade, Unknown) or cand.grade is None:
                out.ineligible.append(f"{cand.id}: unknown grade, never auto-proposed")
                continue
            if cand.grade.high > limit:
                out.ineligible.append(f"{cand.id}: grade upper bound T{cand.grade.high} above limit T{limit}")
                continue
            snap = weather(cand, plan.model_copy(update={"route_id": cand.id}))
            if snap is None:
                out.ineligible.append(f"{cand.id}: weather unavailable")
                continue
            trial = engine.assess(cand, plan, snap, base.warnings, now)
            if _improves(base, trial, trigger.id):
                out.recommendations.append(Recommendation(
                    id=f"rec:alt:{cand.id}", kind="alternative", justifies=[trigger.id],
                    slots={"route_id": cand.id, "route_name": cand.name, "grade": cand.grade.label(),
                           "worst": trial.assessment.severity.value, "place": trigger.slots.get("place", "")},
                    provenance=DerivedProvenance(input_fact_ids=[trigger.id, trial.assessment.id], rule_id="ALT-ROUTE-01",
                                                 rule_version=1, confidence=trial.assessment.confidence)))
            else:
                out.ineligible.append(f"{cand.id}: does not remove or lower {trigger.id}")
    if not [r for r in out.recommendations if r.provenance.rule_id in ("MIT-START-01", "ALT-ROUTE-01")]:
        out.none_found_reason = NONE_FOUND
    return out
