"""Fusion post-conditions INV-1..3 (ARCHITECTURE §7; CONTEXT: Fusion post-condition).

INV-1 repaired: unjustified recommendation dropped. INV-2 repaired: derived hazard subordinated to an
official warning in its category. INV-3 fatal: a hazard without linked evidence means no assessment.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from hsa.adapters.warnings import WarningsStatus
from hsa.domain.models import Recommendation, RiskAssessment


@dataclass
class PostConditionResult:
    assessment: RiskAssessment | None
    repairs: list[str] = field(default_factory=list)
    disclosures: list[str] = field(default_factory=list)
    fatal: str | None = None


def apply_post_conditions(assessment: RiskAssessment, recommendations: list[Recommendation],
                          warnings: WarningsStatus, known_fact_ids: set[str]) -> PostConditionResult:
    repairs: list[str] = []
    # INV-3 first: fatal
    for h in assessment.hazards:
        evidence = [i for i in h.provenance.input_fact_ids if i in known_fact_ids]
        if not evidence:
            return PostConditionResult(assessment=None, fatal=f"INV-3: hazard {h.id} has no linked evidence; assessment not produced")
    hazards = [h.model_copy() for h in assessment.hazards]
    # INV-2
    disclosures: list[str] = []
    if warnings.available:
        for w in warnings.warnings:
            for h in hazards:
                if h.category == w.category and h.subordinated_to_warning is None:
                    h.subordinated_to_warning = w.id
                    repairs.append(f"INV-2: {h.id} subordinated to official warning {w.id} ({w.source} level {w.level})")
    else:
        disclosures.append(warnings.disclosure)
    # INV-1
    hazard_ids = {h.id for h in hazards} | {assessment.id}
    kept: list[Recommendation] = []
    for r in recommendations:
        if all(j in hazard_ids for j in r.justifies):
            kept.append(r)
        else:
            repairs.append(f"INV-1: recommendation {r.id} dropped; justifies {r.justifies} not in assessment")
    out = assessment.model_copy(update={"hazards": hazards, "recommendations": kept})
    return PostConditionResult(assessment=out, repairs=repairs, disclosures=disclosures)
