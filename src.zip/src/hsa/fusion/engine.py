"""Fusion engine core (ARCHITECTURE §6.4): deterministic rule join per segment and traversal hour."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from hsa.adapters.warnings import WarningsStatus
from hsa.domain.models import (HikePlan, Hazard, RiskAssessment, Route, Segment, Severity, Unknown,
                               WeatherCondition)
from hsa.domain.provenance import DerivedProvenance
from hsa.fusion.confidence import condition_confidence
from hsa.geo.traversal import traversal_windows
from hsa.rules.loader import Catalogue
from hsa.rules.schema import evaluate_rule
from hsa.weather.snapshot import WeatherSnapshot

STALE_AFTER_HOURS = 6.0


@dataclass
class Coverage:
    rules_total: int = 0
    evaluated: int = 0
    not_evaluated: list[tuple[str, str, list[str]]] = field(default_factory=list)  # (segment_id, rule_id, missing)


@dataclass
class FusionResult:
    assessment: RiskAssessment
    coverage: Coverage
    windows: dict[str, tuple[datetime, datetime]]
    warnings: WarningsStatus


from zoneinfo import ZoneInfo

ZURICH = ZoneInfo("Europe/Zurich")


def _hhmm(t: datetime) -> str:
    return t.astimezone(ZURICH).strftime("%H:%M")


def _inputs(seg: Segment, wc: WeatherCondition) -> dict:
    return {
        "gust_kmh": wc.gust_kmh, "temperature_c": wc.temperature_c, "precipitation_mm": wc.precipitation_mm,
        "cloud_base_m": wc.cloud_base_m, "freezing_level_m": wc.freezing_level_m, "cape_jkg": wc.cape_jkg,
        "exposure": seg.exposure, "fixed_cables": seg.fixed_cables, "descent_m": seg.descent_m,
        "ascent_m": seg.ascent_m, "elevation_max_m": seg.elevation_max_m, "place": seg.place or seg.name.split("→")[-1].strip(),
    }


class FusionEngine:
    def __init__(self, catalogue: Catalogue):
        self.cat = catalogue

    def assess(self, route: Route, plan: HikePlan, snap: WeatherSnapshot, warnings: WarningsStatus,
               now: datetime) -> FusionResult:
        wins = {w.segment_id: (w.start, w.end) for w in traversal_windows(route.segments, plan.start_time, plan.pace_factor)}
        by_seg: dict[str, list[WeatherCondition]] = {}
        for wc in snap.conditions:
            by_seg.setdefault(wc.segment_id, []).append(wc)
        hazards: list[Hazard] = []
        cov = Coverage()
        trace: list[str] = []
        evidence: set[str] = set()
        data_age = now - snap.run_time
        for seg in route.segments:
            start, end = wins[seg.id]
            hour0 = start.replace(minute=0, second=0, microsecond=0)
            conds = [c for c in by_seg.get(seg.id, []) if hour0 <= c.valid_at <= end]
            for rule in self.cat.rules:
                cov.rules_total += 1
                if not conds:
                    cov.not_evaluated.append((seg.id, rule.id, ["weather"]))
                    continue
                fired_hours: list[WeatherCondition] = []
                missing_all: set[str] = set()
                for wc in conds:
                    r = evaluate_rule(rule, _inputs(seg, wc))
                    if r.status == "not_evaluated":
                        missing_all.update(r.missing)
                    elif r.status == "fired":
                        fired_hours.append(wc)
                if missing_all and not fired_hours:
                    cov.not_evaluated.append((seg.id, rule.id, sorted(missing_all)))
                    continue
                cov.evaluated += 1
                if not fired_hours:
                    continue
                first, last = fired_hours[0], fired_hours[-1]
                peak = max(fired_hours, key=lambda c: (c.gust_kmh if not isinstance(c.gust_kmh, Unknown) else 0))
                conf = condition_confidence(peak.provenance.confidence, data_age, first.valid_at - now)
                inputs = [c.id for c in fired_hours] + [seg.id]
                slots = {k: v for k, v in _inputs(seg, peak).items() if not isinstance(v, Unknown)}
                slots.update({"hour_from": _hhmm(first.valid_at), "hour_to": _hhmm(last.valid_at.replace(minute=59)),
                              "elevation_m": round(seg.elevation_max_m)})
                for k, v in list(slots.items()):
                    if isinstance(v, float):
                        slots[k] = round(v)
                h = Hazard(id=f"hz:{rule.id}:{seg.index}", segment_id=seg.id, category=rule.category,
                           severity=rule.severity, window_start=first.valid_at, window_end=last.valid_at,
                           slots=slots, provenance=DerivedProvenance(input_fact_ids=inputs, rule_id=rule.id,
                                                                     rule_version=rule.version, confidence=conf))
                hazards.append(h)
                evidence.update(inputs)
                trace.append(f"{h.provenance.rule_ref} fired on {seg.name} {slots['hour_from']}–{slots['hour_to']} "
                             f"({rule.justification}) confidence {conf}")
        sev = max((h.severity for h in hazards), key=lambda s: s.rank, default=Severity.NONE)
        conf = min((h.provenance.confidence for h in hazards), default=0.8)
        stale = data_age.total_seconds() / 3600 > STALE_AFTER_HOURS
        a = RiskAssessment(id=f"ra:{route.id}:{plan.start_time.isoformat()}", route_id=route.id, hazards=hazards,
                           severity=sev, confidence=conf, evidence_ids=sorted(evidence), reasoning_trace=trace, stale=stale)
        return FusionResult(assessment=a, coverage=cov, windows=wins, warnings=warnings)
