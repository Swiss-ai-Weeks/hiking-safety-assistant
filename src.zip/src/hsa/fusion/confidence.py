"""Confidence from source confidence, data age, and forecast lead time (ARCHITECTURE §6.3)."""
from __future__ import annotations

from datetime import timedelta


def condition_confidence(source_confidence: float, data_age: timedelta, lead_time: timedelta,
                         warning_level: int | None = None) -> float:
    age_h = max(data_age.total_seconds() / 3600.0, 0.0)
    lead_h = max(lead_time.total_seconds() / 3600.0, 0.0)
    age_factor = max(0.35, 1.0 - 0.05 * age_h)          # -5 % per hour of age, floor 0.35
    lead_factor = max(0.3, 1.0 - 0.008 * lead_h)         # -0.8 % per hour of lead time, floor 0.3
    c = source_confidence * age_factor * lead_factor
    if warning_level is not None and warning_level >= 2:
        c = min(1.0, c + 0.1)  # an official warning corroborates the derived signal
    return round(max(0.0, min(1.0, c)), 3)
