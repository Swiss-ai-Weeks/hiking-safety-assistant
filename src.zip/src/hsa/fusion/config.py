"""Tunables for mitigations and alternatives (ARCHITECTURE §8; placeholders for detailed design)."""
SEVERITY_THRESHOLD = "moderate"   # hazards at or above this trigger mitigations/alternatives
CANDIDATE_LIMIT_N = 3
CANDIDATE_RADIUS_M = 5000.0
START_SHIFTS_HOURS = (-1, -2)     # earlier starts tried, in order
