"""Weather snapshot: keyed, TTL-bound, in memory only (CONTEXT: Weather snapshot; KAD-1)."""
from __future__ import annotations

from datetime import date, datetime, timedelta

from pydantic import BaseModel, Field

from hsa.domain.models import WeatherCondition


class SnapshotKey(BaseModel, frozen=True):
    route_id: str
    hike_date: date
    start_hour: int
    pace_factor: float
    forecast_window: str  # "ch1" (<=33 h) or "ch2" (<=120 h)


class WeatherSnapshot(BaseModel):
    key: SnapshotKey
    fetched_at: datetime
    run_time: datetime  # forecast model run the data came from
    conditions: list[WeatherCondition]
    ttl: timedelta = Field(default=timedelta(hours=3))
    source: str = "meteoswiss"

    def valid_at(self, now: datetime) -> bool:
        return now - self.fetched_at < self.ttl

    def age_at(self, now: datetime) -> timedelta:
        return now - self.run_time


class SnapshotStore:
    backend = "memory"

    def __init__(self) -> None:
        self._items: dict[SnapshotKey, WeatherSnapshot] = {}

    def put(self, snap: WeatherSnapshot) -> None:
        self._items[snap.key] = snap

    def get_valid_or_none(self, key: SnapshotKey, now: datetime) -> WeatherSnapshot | None:
        snap = self._items.get(key)
        if snap is None or not snap.valid_at(now):
            return None
        return snap
