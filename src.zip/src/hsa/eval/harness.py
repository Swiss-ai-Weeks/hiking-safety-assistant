"""AIQ offline harness (ARCHITECTURE §6.1): measures the planner, never enforces safety.

Scores per golden case: decomposition (expected tools called), phrase selection (an expected identifier
chosen), excerpt relevance (corpus lookup returns the expected term), discarded text blocks, and the one
metric that must always be zero: free LLM text reaching the user.
"""
from __future__ import annotations

from pathlib import Path
from typing import Callable

from hsa.corpus.store import CorpusStore
from hsa.gate.phrase_bank import PhraseBank
from hsa.planner.planner import Planner
from hsa.planner.session import SessionStore

ROOT = Path(__file__).resolve().parents[3]


def score_cases(cases: list[dict], client_factory: Callable[[dict], object]) -> dict:
    bank = PhraseBank.load(ROOT / "phrasebank")
    corpus = CorpusStore.load(ROOT / "src/hsa/corpus/data")
    allowed = [pid for pid in bank._p["en"]]
    report = {"n": 0, "decomposition_ok": 0, "phrase_ok": 0, "excerpt_ok": 0, "discarded_text_blocks": 0,
              "free_text_reached_user": 0, "cases": []}
    for case in cases:
        report["n"] += 1
        calls = []

        def execute(name, args, _calls=calls):
            _calls.append(name)
            if name == "lookup_corpus":
                hits = corpus.lookup(args.get("query", ""), lang="en", limit=1)
                return {"excerpts": [h.text for h in hits]}
            return {"ok": True}

        planner = Planner(client_factory(case), execute, phrase_ids=allowed)
        out = planner.plan(case["question"], SessionStore().get(case["id"]))
        decomposition = all(t in out.tool_calls for t in case["expect_tools"])
        phrase = any(p in out.phrase_ids for p in case["expect_phrases_any"])
        excerpt = None
        if case.get("corpus_query"):
            hits = corpus.lookup(case["corpus_query"], lang="en", limit=1)
            excerpt = bool(hits) and case.get("expect_excerpt_contains", "") in hits[0].text
        report["decomposition_ok"] += int(decomposition)
        report["phrase_ok"] += int(phrase)
        report["excerpt_ok"] += int(bool(excerpt))
        report["discarded_text_blocks"] += out.discarded_text_blocks
        # by construction the planner exposes no text; this stays zero unless someone breaks the boundary
        report["free_text_reached_user"] += int(hasattr(out, "text"))
        report["cases"].append({"id": case["id"], "decomposition": decomposition, "phrase": phrase, "excerpt": excerpt,
                                "tools": out.tool_calls, "rejected_phrases": out.rejected_phrase_ids})
    return report
