"""MeteoSwiss OGD adapter (ARCHITECTURE §6.3, R-7, R-8). Verified 2026-09-14 against the STAC API.

STAC:   POST https://data.geo.admin.ch/api/stac/v1/search with collections + forecast:variable +
        forecast:perturbed=false. Items carry forecast:reference_datetime, forecast:horizon (ISO 8601
        duration), forecast:variable; one GRIB2 asset each (control run suffix ``-ct``).
Grid:   ICON-CH1/CH2 GRIB2 use an unstructured (icosahedral) grid. Cell lat/lon come from the static
        asset ``horizontal_constants_icon-ch<1|2>-eps.grib2`` (CLAT/CLON). Nearest cell per segment
        centroid; never interpolate (R-8). Regular lat/lon GRIB2 (test fixtures) decode directly.
Vars:   T_2M (K), VMAX_10M (m/s, max over previous hour), TOT_PREC (accumulated since reference),
        CAPE_ML (J/kg), HZEROCL (m, freezing level), HBAS_SC (m, cloud base), CLCT (%).
Params list: collection asset params_icon-ch1-eps.csv.
"""
from __future__ import annotations

import math
import re
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path

import httpx
import numpy as np

from hsa.domain.models import Segment, Unknown, WeatherCondition
from hsa.domain.provenance import SourceProvenance
from hsa.weather.snapshot import SnapshotKey, WeatherSnapshot

STAC = "https://data.geo.admin.ch/api/stac/v1"
CH1 = "ch.meteoschweiz.ogd-forecasting-icon-ch1"
CH2 = "ch.meteoschweiz.ogd-forecasting-icon-ch2"
VARIABLES = ["T_2M", "VMAX_10M", "TOT_PREC", "CAPE_ML", "HZEROCL", "HBAS_SC", "CLCT"]
CACHE = Path.home() / ".cache" / "hsa" / "grib"


def choose_collection(lead: timedelta) -> str | None:
    h = lead.total_seconds() / 3600
    if h <= 33:
        return CH1
    if h <= 120:
        return CH2
    return None


def select_collection_for(ref: datetime, hours: list[datetime]) -> str | None:
    """Collection by the horizon needed from the run's reference time (CH1 33 h, CH2 120 h)."""
    need = max(hours) - ref
    return choose_collection(need)


def parse_horizon(iso: str) -> timedelta:
    m = re.fullmatch(r"P(?:(\d+)D)?T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?", iso)
    if not m:
        raise ValueError(f"bad horizon {iso!r}")
    d, h, mi, s = (int(x) if x else 0 for x in m.groups())
    return timedelta(days=d, hours=h, minutes=mi, seconds=s)


@dataclass
class GribField:
    """One decoded 2-D field with cell coordinates. ``values`` aligned with ``lats``/``lons``."""

    values: np.ndarray
    lats: np.ndarray
    lons: np.ndarray

    @classmethod
    def load(cls, path: Path, constants: "GribField | None" = None) -> "GribField":
        import eccodes as ec

        with open(path, "rb") as f:
            h = ec.codes_grib_new_from_file(f)
            try:
                grid = ec.codes_get(h, "gridType")
                vals = np.asarray(ec.codes_get_values(h), dtype=float)
                if grid == "unstructured_grid":
                    if constants is None:
                        raise ValueError("unstructured grid needs horizontal constants (CLAT/CLON)")
                    return cls(vals, constants.lats, constants.lons)
                lats = np.asarray(ec.codes_get_array(h, "latitudes"), dtype=float)
                lons = np.asarray(ec.codes_get_array(h, "longitudes"), dtype=float)
                return cls(vals, lats, lons)
            finally:
                ec.codes_release(h)

    def nearest(self, lat: float, lon: float) -> float:
        d = (self.lats - lat) ** 2 + ((self.lons - lon) * math.cos(math.radians(lat))) ** 2
        i = int(np.argmin(d))
        v = float(self.values[i])
        return v


def _centroid(seg: Segment) -> tuple[float, float]:
    lat = sum(c[0] for c in seg.coords) / len(seg.coords)
    lon = sum(c[1] for c in seg.coords) / len(seg.coords)
    return lat, lon


def _u(v):  # to Unknown when missing
    return Unknown() if v is None or (isinstance(v, float) and math.isnan(v)) else v


def conditions_from_fields(segments: list[Segment], fields: dict[datetime, dict[str, GribField]],
                           run_time: datetime, source: str = "meteoswiss:icon-ch1") -> list[WeatherCondition]:
    """Nearest-cell extraction per segment centroid per valid hour. Missing variables become Unknown."""
    out: list[WeatherCondition] = []
    hours = sorted(fields)
    prev_prec: dict[str, float] = {}
    for t in hours:
        fs = fields[t]
        for seg in segments:
            lat, lon = _centroid(seg)
            get = lambda name: fs[name].nearest(lat, lon) if name in fs else None  # noqa: E731
            t2m, vmax, prec_acc, cape, hz, hbas = (get(n) for n in ("T_2M", "VMAX_10M", "TOT_PREC", "CAPE_ML", "HZEROCL", "HBAS_SC"))
            precip_h = None
            if prec_acc is not None:
                precip_h = max(prec_acc - prev_prec.get(seg.id, 0.0), 0.0)
                prev_prec[seg.id] = prec_acc
            out.append(WeatherCondition(
                id=f"wc:{seg.index}:{t.strftime('%Y%m%dT%H')}", segment_id=seg.id, valid_at=t,
                temperature_c=_u(None if t2m is None else round(t2m - 273.15, 1)),
                gust_kmh=_u(None if vmax is None else round(vmax * 3.6, 1)),
                precipitation_mm=_u(precip_h), cloud_base_m=_u(hbas), freezing_level_m=_u(hz), cape_jkg=_u(cape),
                provenance=SourceProvenance(source=source, observed_at=run_time, confidence=0.85)))
    return out


class MeteoSwissClient:
    def __init__(self, timeout: float = 60.0, cache: Path = CACHE):
        self._http = httpx.Client(timeout=timeout, headers={"User-Agent": "hsa-prototype/0.1"}, follow_redirects=True)
        self.cache = cache
        self.cache.mkdir(parents=True, exist_ok=True)

    def _parse_items(self, data: dict) -> list[dict]:
        items = []
        for f in data.get("features", []):
            p = f["properties"]
            asset = next(iter(f["assets"].values()))
            items.append({"ref": datetime.fromisoformat(p["forecast:reference_datetime"].replace("Z", "+00:00")),
                          "horizon": parse_horizon(p["forecast:horizon"]), "variable": p["forecast:variable"],
                          "perturbed": bool(p.get("forecast:perturbed")), "href": asset["href"], "id": f["id"]})
        return items

    def search(self, collection: str, variable: str, ref: str | None = None, limit: int = 100) -> list[dict]:
        """STAC search. The API caps pages at 100, returns oldest-first, has no sortby, and paginates via a
        ``next`` link carrying the POST body; ``forecast:reference_datetime`` accepts a value or a start/end range."""
        body = {"collections": [collection], "forecast:variable": variable, "forecast:perturbed": False, "limit": limit}
        if ref is not None:
            body["forecast:reference_datetime"] = ref
        items: list[dict] = []
        for _ in range(10):
            r = self._http.post(f"{STAC}/search", json=body)
            r.raise_for_status()
            data = r.json()
            items += self._parse_items(data)
            nxt = next((l for l in data.get("links", []) if l.get("rel") == "next"), None)
            if not nxt:
                break
            body = {**body, **nxt.get("body", {})} if nxt.get("merge") else nxt.get("body", body)
        return items

    def latest_run(self, collection: str, variable: str, now: datetime | None = None, lookback_h: int = 30) -> tuple[datetime | None, list[dict]]:
        now = now or datetime.now(timezone.utc)
        rng = f"{(now - timedelta(hours=lookback_h)).strftime('%Y-%m-%dT%H:%M:%SZ')}/{now.strftime('%Y-%m-%dT%H:%M:%SZ')}"
        recent = self.search(collection, variable, ref=rng)
        if not recent:
            return None, []
        ref = max(i["ref"] for i in recent)
        full = self.search(collection, variable, ref=ref.strftime("%Y-%m-%dT%H:%M:%SZ"))
        return ref, [i for i in full if i["ref"] == ref]

    def constants(self, collection: str) -> GribField:
        name = "horizontal_constants_icon-ch1-eps.grib2" if collection == CH1 else "horizontal_constants_icon-ch2-eps.grib2"
        path = self.cache / name
        if not path.exists():
            meta = self._http.get(f"{STAC}/collections/{collection}/assets/{name}").json()
            self._download(meta["href"], path)
        import eccodes as ec

        lats = lons = None
        with open(path, "rb") as f:
            while True:
                h = ec.codes_grib_new_from_file(f)
                if h is None:
                    break
                sn = ec.codes_get(h, "shortName")
                arr = np.asarray(ec.codes_get_values(h), dtype=float)
                if sn.upper() in ("CLAT", "TLAT"):
                    lats = arr
                elif sn.upper() in ("CLON", "TLON"):
                    lons = arr
                ec.codes_release(h)
        if lats is None or lons is None:
            raise RuntimeError("CLAT/CLON not found in horizontal constants")
        return GribField(np.zeros_like(lats), lats, lons)

    def _download(self, href: str, path: Path) -> Path:
        if not path.exists():
            with self._http.stream("GET", href) as r:
                r.raise_for_status()
                tmp = path.with_suffix(".part")
                with open(tmp, "wb") as f:
                    for chunk in r.iter_bytes():
                        f.write(chunk)
                tmp.rename(path)
        return path

    def fetch_snapshot(self, segments: list[Segment], key: SnapshotKey, hours: list[datetime],
                       now: datetime | None = None, variables: list[str] = VARIABLES) -> WeatherSnapshot | None:
        """Newest run whose horizon covers the hike hours; CH1 if 33 h suffice from that run, else CH2."""
        now = now or datetime.now(timezone.utc)
        try:
            ref1, _ = self.latest_run(CH1, variables[0], now=now)
        except httpx.HTTPError:
            ref1 = None
        collection = select_collection_for(ref1, hours) if ref1 else CH2
        if collection is None:
            return None
        runs: dict[str, tuple[datetime, list[dict]]] = {}
        for v in variables:
            try:
                r, items = self.latest_run(collection, v, now=now)
                if r is not None:
                    runs[v] = (r, items)
            except httpx.HTTPError:
                continue
        if not runs:
            return None
        ref = max(r for r, _ in runs.values())  # newest run; variables missing from it become Unknown
        if collection == CH1 and select_collection_for(ref, hours) != CH1:
            collection = CH2  # the newest CH1 run cannot reach the hike hours; fall back to CH2 for this fetch
            runs = {v: self.latest_run(CH2, v, now=now) for v in variables}
            runs = {v: rv for v, rv in runs.items() if rv[0] is not None}
            ref = max(r for r, _ in runs.values())
        consts = self.constants(collection)
        wanted: list[tuple[datetime, str, dict]] = []
        for v, (r, items) in runs.items():
            if r != ref:
                continue
            for it in items:
                valid = ref + it["horizon"]
                if any(abs((valid - h).total_seconds()) < 1800 for h in hours):
                    wanted.append((valid, v, it))

        def get(w):
            valid, v, it = w
            path = self._download(it["href"], self.cache / f"{it['id']}.grib2")
            return valid, v, GribField.load(path, constants=consts)

        fields: dict[datetime, dict[str, GribField]] = {}
        with ThreadPoolExecutor(max_workers=8) as ex:
            for valid, v, fld in ex.map(get, wanted):
                fields.setdefault(valid, {})[v] = fld
        if not fields:
            return None
        conds = conditions_from_fields(segments, fields, run_time=ref,
                                       source="meteoswiss:icon-ch1" if collection == CH1 else "meteoswiss:icon-ch2")
        return WeatherSnapshot(key=key, fetched_at=now, run_time=ref, conditions=conds)
