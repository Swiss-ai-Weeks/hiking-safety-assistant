"""Official warnings source (ARCHITECTURE §7 'Warnings in the slice', R-6).

No stable, documented public JSON feed for aggregated MeteoSwiss or natural-hazard warnings
was found in September 2026. The slice ships ``UnavailableWarnings``: INV-2 has nothing to
subordinate to, and the response discloses that warnings were not checked (DR-3).
"""
from __future__ import annotations

from typing import Protocol

from pydantic import BaseModel


class Channel(BaseModel):
    label: str
    href: str


class OfficialWarning(BaseModel):
    id: str
    category: str  # wind, precipitation, thunderstorm, snow, avalanche
    level: int
    valid_from: str
    valid_to: str
    source: str


class WarningsStatus(BaseModel):
    available: bool
    reason: str = ""
    warnings: list[OfficialWarning] = []
    channels: list[Channel] = []

    @property
    def disclosure(self) -> str:
        if self.available:
            return ""
        return "Official weather warnings could not be checked. Check MeteoSwiss and the SLF bulletin yourself."


CHANNELS = [
    Channel(label="MeteoSwiss warnings", href="https://www.meteoswiss.admin.ch/services-and-publications/warnings.html"),
    Channel(label="SLF avalanche bulletin", href="https://www.slf.ch/en/avalanche-bulletin-and-snow-situation.html"),
]


class WarningsSource(Protocol):
    def fetch(self, region: str) -> WarningsStatus: ...


class UnavailableWarnings:
    def fetch(self, region: str) -> WarningsStatus:
        return WarningsStatus(available=False, channels=CHANNELS,
                              reason="No stable public warnings feed is available to this prototype (unavailable by design, R-6).")
