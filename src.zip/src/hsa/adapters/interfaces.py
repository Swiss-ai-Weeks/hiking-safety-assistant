from __future__ import annotations

from typing import Protocol

from pydantic import BaseModel

from hsa.domain.models import Route


class Unresolved(BaseModel):
    """Route could not be resolved on the official network. Never an exception (DR-3)."""

    reason: str


class RouteSource(Protocol):
    def resolve_by_name(self, name: str) -> Route | Unresolved: ...
    def resolve_by_points(self, start: tuple[float, float], end: tuple[float, float]) -> Route | Unresolved: ...
    def candidates_near(self, start: tuple[float, float], radius_m: float, limit: int) -> list[Route]: ...
