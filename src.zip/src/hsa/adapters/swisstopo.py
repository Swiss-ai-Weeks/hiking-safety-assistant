"""swisstopo adapter (ARCHITECTURE §6.2, §11 verify-first).

Endpoints (api3.geo.admin.ch), verified live 2026-09-14:
- profile:  POST /rest/services/profile.json  geom=GeoJSON LineString in EPSG:2056  -> [{dist, alts{COMB,DTM2,DTM25}}]
- identify: GET  /rest/services/api/MapServer/identify layers=all:ch.swisstopo.swisstlm3d-wanderwege
            needs tolerance ~100 px; attribute is ``hikingtype`` (Wanderweg | Bergwanderweg | Alpinwanderweg)
- identify: same on ch.astra.wanderland -> ``chmobil_title`` (e.g. "Via Alpina (Griesalp - Kandersteg)")
- find:     GET  /rest/services/api/MapServer/find layer=ch.astra.wanderland searchField=chmobil_title
            (``name`` is not a searchable field; fields are id, chmobil_route_number, chmobil_title)
Trail category yields only a T-grade *range*: Wanderweg T1, Bergwanderweg T2–T3, Alpinwanderweg T4–T6.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone

import httpx
from pyproj import Transformer

from hsa.adapters.interfaces import Unresolved
from hsa.domain.models import GradeRange, Route
from hsa.domain.provenance import SourceProvenance
from hsa.geo.segment import haversine_m, split_at_indices, split_route

BASE = "https://api3.geo.admin.ch/rest/services"
_TO_LV95 = Transformer.from_crs("EPSG:4326", "EPSG:2056", always_xy=True)

# Friendly names hikers use, mapped to start/end points on the official network. Resolution still goes
# through the network (identify at both points, intersect Wanderland titles); nothing here is a route.
FRIENDLY_ROUTES: dict[str, tuple[tuple[float, float], tuple[float, float]]] = {
    "oeschinensee → blüemlisalphütte": ((46.4985, 7.7275), (46.4940, 7.7740)),
    "oeschinensee → bluemlisalphuette": ((46.4985, 7.7275), (46.4940, 7.7740)),
    "griesalp → kandersteg": ((46.5760, 7.7680), (46.4940, 7.6740)),
}

CATEGORY_GRADE = {
    "wanderweg": GradeRange(low=1, high=1, exact=True),
    "bergwanderweg": GradeRange(low=2, high=3),
    "alpinwanderweg": GradeRange(low=4, high=6),
}


def trail_category_to_grade(category: str | None) -> GradeRange | None:
    if not category:
        return None
    return CATEGORY_GRADE.get(category.strip().lower())


def route_from_record(rec: dict) -> Route:
    coords = [tuple(c) for c in rec["coords"]]
    profile = rec["profile_m"]
    prov = SourceProvenance(source=rec["source"], observed_at=datetime.fromisoformat(
        rec["observed_at"].replace("Z", "+00:00")), confidence=0.9)
    if rec.get("breakpoints"):
        segs = split_at_indices(rec["id"], coords, profile, rec["breakpoints"], names=rec.get("names"))
    else:
        segs = split_route(rec["id"], coords, profile, names=rec.get("names"))
    grade = trail_category_to_grade(rec.get("trail_category"))
    for s in segs:
        if grade is not None:
            s.grade = grade
        if rec.get("places") and s.index < len(rec["places"]):
            s.place = rec["places"][s.index]["name"]
            s.place_elevation_m = rec["places"][s.index].get("elevation_m")
        if rec.get("exposure") is not None and s.index < len(rec["exposure"]):
            s.exposure = bool(rec["exposure"][s.index])
        if rec.get("fixed_cables") is not None and s.index < len(rec["fixed_cables"]):
            s.fixed_cables = bool(rec["fixed_cables"][s.index])
        s.provenance = prov
    if rec.get("segment_categories") and rec.get("_client") is not None:
        rec["_client"].derive_exposure(segs, coords, profile)
    length = sum(haversine_m(a, b) for a, b in zip(coords, coords[1:]))
    ascent = sum(max(b - a, 0.0) for a, b in zip(profile, profile[1:]))
    return Route(id=rec["id"], name=rec["name"], coords=coords, grade=grade or Route.model_fields["grade"].default_factory(),
                 length_m=length, ascent_m=ascent, segments=segs, provenance=prov)


class SwisstopoClient:
    """Thin live client. Each method returns plain data; ``resolve_*`` wrap them into Routes."""

    def __init__(self, timeout: float = 15.0):
        self._http = httpx.Client(base_url=BASE, timeout=timeout, headers={"User-Agent": "hsa-prototype/0.1"})

    def profile(self, coords: list[tuple[float, float]], nb_points: int = 50) -> list[dict]:
        line = {"type": "LineString", "coordinates": [list(_TO_LV95.transform(lon, lat)) for lat, lon in coords]}
        r = self._http.post("/profile.json", data={"geom": json.dumps(line), "sr": "2056", "nb_points": str(nb_points)})
        r.raise_for_status()
        return [{"dist": p["dist"], "alt": p["alts"].get("COMB") or p["alts"].get("DTM2"),
                 "easting": p["easting"], "northing": p["northing"]} for p in r.json()]

    def identify_trails(self, point: tuple[float, float], tolerance_px: int = 100) -> list[dict]:
        lat, lon = point
        r = self._http.get("/api/MapServer/identify", params={
            "geometry": f"{lon},{lat}", "geometryType": "esriGeometryPoint", "sr": "4326",
            "layers": "all:ch.swisstopo.swisstlm3d-wanderwege", "tolerance": str(tolerance_px),
            "mapExtent": f"{lon-0.02},{lat-0.02},{lon+0.02},{lat+0.02}", "imageDisplay": "800,600,96",
            "returnGeometry": "true"})
        r.raise_for_status()
        return r.json().get("results", [])

    def find_wanderland(self, title: str) -> list[dict]:
        r = self._http.get("/api/MapServer/find", params={
            "layer": "ch.astra.wanderland", "searchText": title, "searchField": "chmobil_title",
            "returnGeometry": "true", "sr": "4326", "contains": "true"})
        r.raise_for_status()
        return r.json().get("results", [])

    def identify_wanderland(self, point: tuple[float, float], tolerance_px: int = 300) -> list[dict]:
        lat, lon = point
        r = self._http.get("/api/MapServer/identify", params={
            "geometry": f"{lon},{lat}", "geometryType": "esriGeometryPoint", "sr": "4326",
            "layers": "all:ch.astra.wanderland", "tolerance": str(tolerance_px),
            "mapExtent": f"{lon-0.03},{lat-0.03},{lon+0.03},{lat+0.03}", "imageDisplay": "800,600,96",
            "returnGeometry": "false"})
        r.raise_for_status()
        return r.json().get("results", [])

    def derive_exposure(self, segs, coords, profile) -> None:
        """Exposure per segment from the swissTLM3D trail category at the segment's highest point.

        Alpinwanderweg (white-blue-white) is exposed by SAC definition (T4+): exposure True.
        Wanderweg (yellow, T1): exposure False. Bergwanderweg (T2–T3): can be either, stays Unknown.
        """
        for s in segs:
            try:
                hi = max(range(len(s.coords)), key=lambda i: profile[coords.index(s.coords[i])])
                trails = self.identify_trails(s.coords[hi])
                cat = (trails[0]["attributes"].get("hikingtype") or "").lower() if trails else ""
            except (httpx.HTTPError, ValueError, IndexError):
                cat = ""
            if cat == "alpinwanderweg":
                s.exposure = True
                s.grade = CATEGORY_GRADE[cat]
            elif cat == "wanderweg":
                s.exposure = False
                s.grade = CATEGORY_GRADE[cat]
            elif cat == "bergwanderweg":
                s.grade = CATEGORY_GRADE[cat]

    # RouteSource protocol
    def resolve_by_name(self, name: str) -> Route | Unresolved:
        try:
            hits = self.find_wanderland(name)
        except httpx.HTTPError as e:
            return Unresolved(reason=f"swisstopo unavailable: {e.__class__.__name__}")
        if hits:
            return self._route_from_feature(hits[0])
        alias = FRIENDLY_ROUTES.get(name.strip().lower().replace("->", "→"))
        if alias:
            r = self.resolve_by_points(*alias)
            if not isinstance(r, Unresolved):
                r.name = f"{name} (on {r.name})"
                return r
            return Unresolved(reason=f"no official route named {name!r}; the network has no single route between its start and end either ({r.reason})")
        return Unresolved(reason=f"no official route named {name!r}")

    def resolve_by_points(self, start, end) -> Route | Unresolved:
        """Official routes passing near both points: intersect Wanderland titles at start and end."""
        try:
            a = {f["attributes"].get("chmobil_title") for f in self.identify_wanderland(start)}
            b = {f["attributes"].get("chmobil_title") for f in self.identify_wanderland(end)}
        except httpx.HTTPError as e:
            return Unresolved(reason=f"swisstopo unavailable: {e.__class__.__name__}")
        common = sorted(t for t in (a & b) if t)
        if not common:
            return Unresolved(reason="no official Wanderland route passes near both points")
        return self.resolve_by_name(common[0])

    def candidates_near(self, start, radius_m, limit) -> list[Route]:
        return []

    def _route_from_feature(self, feat: dict) -> Route | Unresolved:
        geom = feat.get("geometry", {})
        paths = geom.get("paths") or ([geom["coordinates"]] if "coordinates" in geom else [])
        if not paths:
            return Unresolved(reason="route feature has no geometry")
        coords = [(lat, lon) for lon, lat in paths[0]]
        step = max(1, len(coords) // 60)
        coords = coords[::step] or coords
        prof = self.profile(coords, nb_points=len(coords))
        alts = [p["alt"] for p in prof][: len(coords)]
        while len(alts) < len(coords):
            alts.append(alts[-1])
        attrs = feat.get("attributes", {})
        category = None
        try:  # trail category from the hiking-trail layer at the route's highest point (verify-first row 4)
            hi = coords[max(range(len(alts)), key=lambda i: alts[i])]
            trails = self.identify_trails(hi)
            category = trails[0]["attributes"].get("hikingtype") if trails else None
        except httpx.HTTPError:
            category = None
        rec = {"id": f"wanderland:{feat.get('id') or feat.get('featureId')}", "name": attrs.get("chmobil_title") or attrs.get("label") or "Official route",
               "trail_category": category, "coords": coords, "profile_m": alts, "segment_categories": True,
               "source": "swisstopo ch.astra.wanderland + profile", "observed_at": datetime.now(timezone.utc).isoformat(), "_client": self}
        return route_from_record(rec)
