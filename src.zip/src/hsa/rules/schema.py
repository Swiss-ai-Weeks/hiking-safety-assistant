"""Hazard rule schema and deterministic evaluation (ARCHITECTURE §6.4, CONTEXT: Hazard rule).

Conditions are tiny boolean expressions over named inputs, evaluated with a restricted
evaluator: names, numbers, comparisons, and/or/not. Nothing else is allowed.
"""
from __future__ import annotations

import ast
from dataclasses import dataclass, field
from typing import Any, Literal

from pydantic import BaseModel, Field

from hsa.domain.models import Severity, Unknown


class HazardRule(BaseModel):
    id: str = Field(min_length=1)
    version: int = Field(ge=1)
    category: str = Field(min_length=1)
    inputs: list[str] = Field(min_length=1)
    condition: str = Field(min_length=1)
    severity: Severity
    justification: str = Field(min_length=1)
    basis: str = Field(min_length=1)
    slots: list[str] = []  # extra slot names to expose to templates, beyond inputs


@dataclass
class RuleResult:
    rule: HazardRule
    status: Literal["fired", "not_fired", "not_evaluated"]
    missing: list[str] = field(default_factory=list)
    slots: dict[str, Any] = field(default_factory=dict)


_ALLOWED = (ast.Expression, ast.BoolOp, ast.And, ast.Or, ast.UnaryOp, ast.Not, ast.Compare,
            ast.Name, ast.Load, ast.Constant, ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE)


def _safe_eval(expr: str, env: dict[str, Any]) -> bool:
    tree = ast.parse(expr, mode="eval")
    for node in ast.walk(tree):
        if not isinstance(node, _ALLOWED):
            raise ValueError(f"disallowed expression element {type(node).__name__} in rule condition")
        if isinstance(node, ast.Name) and node.id not in env:
            raise ValueError(f"unknown input {node.id!r}")
    return bool(eval(compile(tree, "<rule>", "eval"), {"__builtins__": {}}, env))


def evaluate_rule(rule: HazardRule, inputs: dict[str, Any]) -> RuleResult:
    missing = [k for k in rule.inputs if k not in inputs or isinstance(inputs[k], Unknown) or inputs[k] is None]
    if missing:
        return RuleResult(rule, "not_evaluated", missing=missing)
    env = {k: inputs[k] for k in rule.inputs}
    fired = _safe_eval(rule.condition, env)
    slots = {k: inputs[k] for k in rule.inputs + rule.slots if k in inputs and not isinstance(inputs[k], Unknown)}
    return RuleResult(rule, "fired" if fired else "not_fired", slots=slots)
