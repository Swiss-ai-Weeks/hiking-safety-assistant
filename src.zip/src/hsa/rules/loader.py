"""Catalogue loader with the per-language template coverage gate (ARCHITECTURE §6.5)."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import yaml

from hsa.rules.schema import HazardRule


class CatalogueError(Exception):
    pass


@dataclass
class Catalogue:
    rules: list[HazardRule]
    templates: dict[tuple[str, str], str]  # (rule_id, lang) -> template text
    languages: tuple[str, ...]

    def template(self, rule_id: str, lang: str) -> str | None:
        return self.templates.get((rule_id, lang))

    def by_id(self, rule_id: str) -> HazardRule:
        return next(r for r in self.rules if r.id == rule_id)


def load_catalogue(rules_dir: Path, templates_dir: Path, languages: tuple[str, ...] = ("en", "de")) -> Catalogue:
    rules: list[HazardRule] = []
    for p in sorted(Path(rules_dir).glob("*.yaml")):
        data = yaml.safe_load(p.read_text())
        try:
            rules.append(HazardRule(**data))
        except Exception as e:  # noqa: BLE001
            raise CatalogueError(f"{p.name}: {e}") from e
    templates: dict[tuple[str, str], str] = {}
    missing: list[str] = []
    for r in rules:
        for lang in languages:
            f = Path(templates_dir) / lang / f"{r.id}.txt"
            if f.exists() and f.read_text().strip():
                templates[(r.id, lang)] = f.read_text().strip()
            else:
                missing.append(f"{r.id}/{lang}")
    if missing:
        raise CatalogueError("template coverage gate failed; missing: " + ", ".join(missing))
    return Catalogue(rules=rules, templates=templates, languages=languages)
