"""Split a route polyline with an elevation profile into segments (ARCHITECTURE §5, R-8).

A new segment starts when the running length would exceed ``max_len_m`` or the running
ascent would exceed ``max_climb_m``. Terrain attributes that no source has supplied stay
``Unknown`` so downstream rules record *not evaluated* instead of treating absence as safe.
"""
from __future__ import annotations

import math

from hsa.domain.models import Segment

EARTH_R = 6_371_000.0


def haversine_m(a: tuple[float, float], b: tuple[float, float]) -> float:
    (lat1, lon1), (lat2, lon2) = a, b
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = p2 - p1
    dl = math.radians(lon2 - lon1)
    h = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * EARTH_R * math.asin(math.sqrt(h))


def split_route(
    route_id: str,
    coords: list[tuple[float, float]],
    profile_m: list[float],
    max_len_m: float = 2500.0,
    max_climb_m: float = 250.0,
    names: list[str] | None = None,
) -> list[Segment]:
    if len(coords) != len(profile_m) or len(coords) < 2:
        raise ValueError("coords and profile must be equal length and at least 2 points")
    segments: list[Segment] = []
    cur = [coords[0]]
    cur_len = cur_up = cur_down = 0.0
    cur_max = profile_m[0]

    def flush(end_idx: int) -> None:
        nonlocal cur, cur_len, cur_up, cur_down, cur_max
        idx = len(segments)
        name = names[idx] if names and idx < len(names) else f"Segment {idx + 1}"
        segments.append(
            Segment(id=f"{route_id}:seg:{idx}", index=idx, name=name, coords=list(cur),
                    length_m=cur_len, ascent_m=cur_up, descent_m=cur_down, elevation_max_m=cur_max)
        )
        cur = [coords[end_idx]]
        cur_len = cur_up = cur_down = 0.0
        cur_max = profile_m[end_idx]

    for i in range(1, len(coords)):
        d = haversine_m(coords[i - 1], coords[i])
        dz = profile_m[i] - profile_m[i - 1]
        up, down = max(dz, 0.0), max(-dz, 0.0)
        if cur_len > 0 and (cur_len + d > max_len_m or cur_up + up > max_climb_m):
            flush(i - 1)
        cur.append(coords[i])
        cur_len += d
        cur_up += up
        cur_down += down
        cur_max = max(cur_max, profile_m[i])
    flush(len(coords) - 1)
    return segments


def split_at_indices(route_id: str, coords: list[tuple[float, float]], profile_m: list[float],
                     breakpoints: list[int], names: list[str] | None = None) -> list[Segment]:
    """Deterministic segmentation at given vertex indices (used when a source supplies named legs)."""
    segments: list[Segment] = []
    for idx, (a, b) in enumerate(zip(breakpoints, breakpoints[1:])):
        cs = coords[a:b + 1]
        ps = profile_m[a:b + 1]
        length = sum(haversine_m(x, y) for x, y in zip(cs, cs[1:]))
        up = sum(max(q - p, 0.0) for p, q in zip(ps, ps[1:]))
        down = sum(max(p - q, 0.0) for p, q in zip(ps, ps[1:]))
        name = names[idx] if names and idx < len(names) else f"Segment {idx + 1}"
        segments.append(Segment(id=f"{route_id}:seg:{idx}", index=idx, name=name, coords=list(cs), length_m=length,
                                ascent_m=up, descent_m=down, elevation_max_m=max(ps)))
    return segments
