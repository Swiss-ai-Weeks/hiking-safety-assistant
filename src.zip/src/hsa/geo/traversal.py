"""Traversal time windows per segment (ARCHITECTURE §5, FR-6).

Reference hiking-time formula (DIN 33466 / SAC): horizontal 4 km/h, ascent 300 m/h,
descent 500 m/h; the total is the larger component plus half the smaller. ``pace_factor``
scales the result; the conservative default in HikePlan is 1.25 (slower than reference).
"""
from __future__ import annotations

from datetime import datetime, timedelta

from hsa.domain.models import Segment, TraversalWindow


def segment_hours(seg: Segment, pace_factor: float = 1.0) -> float:
    horizontal = seg.length_m / 4000.0
    vertical = seg.ascent_m / 300.0 + seg.descent_m / 500.0
    base = max(horizontal, vertical) + 0.5 * min(horizontal, vertical)
    return base * pace_factor


def traversal_windows(segments: list[Segment], start: datetime,
                      pace_factor: float = 1.0) -> list[TraversalWindow]:
    t = start
    out: list[TraversalWindow] = []
    for seg in segments:
        end = t + timedelta(hours=segment_hours(seg, pace_factor))
        if end <= t:
            end = t + timedelta(minutes=1)
        out.append(TraversalWindow(segment_id=seg.id, start=t, end=end))
        t = end
    return out
