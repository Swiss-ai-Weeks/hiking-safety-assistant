"""Approved, slot-free conversational wrapper phrases (ARCHITECTURE §6.5, KAD-8, INV-6 review)."""
from __future__ import annotations

import re
from pathlib import Path

import yaml

VERDICT_PATTERNS = [r"\bsafe\b", r"\bgood to go\b", r"\bgo ahead\b", r"\bclear to\b", r"\bfine to\b", r"\bno risk\b",
                    r"\bsicher\b", r"\bunbedenklich\b", r"\bkein risiko\b", r"\bgefahrlos\b"]
CONTROLLED_VOCAB = [r"\bgust", r"\bthunder", r"\bavalanche", r"\bhazard", r"\bsever", r"\bkm/h\b", r"\bfreezing\b",
                    r"\bböen?\b", r"\bgewitter", r"\blawine", r"\bgefahr\b", r"\bfrost\b", r"\d"]


class PhraseBankError(Exception):
    pass


def review_phrases(phrases: dict[str, str], lang: str) -> None:
    for pid, text in phrases.items():
        low = text.lower()
        for pat in VERDICT_PATTERNS:
            if re.search(pat, low):
                raise PhraseBankError(f"INV-6: phrase {pid!r} ({lang}) matches verdict pattern {pat!r}: {text!r}")
        for pat in CONTROLLED_VOCAB:
            if re.search(pat, low):
                raise PhraseBankError(f"controlled vocabulary: phrase {pid!r} ({lang}) contains {pat!r}; only templates may state facts: {text!r}")


class PhraseBank:
    def __init__(self, phrases: dict[str, dict[str, str]]):
        self._p = phrases  # lang -> id -> text

    @classmethod
    def load(cls, folder: Path) -> "PhraseBank":
        out: dict[str, dict[str, str]] = {}
        for f in sorted(Path(folder).glob("*.yaml")):
            lang = f.stem
            phrases = {str(k): str(v) for k, v in yaml.safe_load(f.read_text()).items()}
            review_phrases(phrases, lang)
            out[lang] = phrases
        langs = list(out)
        if len(langs) > 1:
            ids = [set(out[l]) for l in langs]
            if any(s != ids[0] for s in ids):
                raise PhraseBankError("phrase ids differ between languages")
        return cls(out)

    @property
    def languages(self) -> list[str]:
        return list(self._p)

    def has(self, pid: str, lang: str) -> bool:
        return pid in self._p.get(lang, {})

    def text(self, pid: str, lang: str) -> str:
        return self._p[lang][pid]
