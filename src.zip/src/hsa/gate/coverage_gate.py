"""`make coverage-gate`: per-language template coverage + phrase-bank review + placeholder check."""
from __future__ import annotations

import sys
from pathlib import Path

from hsa.gate.phrase_bank import PhraseBank, PhraseBankError
from hsa.gate.renderer import REC_IDS, load_rec_templates, placeholders
from hsa.rules.loader import CatalogueError, load_catalogue

ROOT = Path(__file__).resolve().parents[3]
KNOWN_SLOTS = {"new_start", "old_start", "shift_h", "turn_place", "turn_by", "route_id", "route_name", "grade", "worst",
               "gust_kmh", "temperature_c", "precipitation_mm", "cloud_base_m", "freezing_level_m", "cape_jkg",
               "exposure", "fixed_cables", "descent_m", "ascent_m", "elevation_max_m", "elevation_m", "place",
               "hour_from", "hour_to"}


def main() -> int:
    ok = True
    try:
        cat = load_catalogue(ROOT / "src/hsa/rules/rules", ROOT / "templates", languages=("en", "de"))
        for (rid, lang), tpl in cat.templates.items():
            extra = placeholders(tpl) - KNOWN_SLOTS
            if extra:
                print(f"FAIL template {rid}/{lang}: unknown slots {sorted(extra)}"); ok = False
        recs = load_rec_templates(ROOT / "templates", cat.languages)
        for rid in REC_IDS:
            for lang in cat.languages:
                if (rid, lang) not in recs:
                    print(f"FAIL recommendation template missing {rid}/{lang}"); ok = False
        print(f"templates: {len(cat.rules)} rules + {len(REC_IDS)} recommendation kinds × {len(cat.languages)} languages covered")
    except CatalogueError as e:
        print("FAIL", e); ok = False
    try:
        bank = PhraseBank.load(ROOT / "phrasebank")
        print(f"phrase bank: {bank.languages} reviewed against verdict patterns and controlled vocabulary")
    except PhraseBankError as e:
        print("FAIL", e); ok = False
    print("coverage gate:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
