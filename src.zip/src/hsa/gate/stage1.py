"""Output gate stage 1 (ARCHITECTURE §6.5): INV-4 stale cap and label, INV-5 cautionary framing."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from hsa.domain.models import RiskAssessment
from hsa.weather.snapshot import WeatherSnapshot
from zoneinfo import ZoneInfo

ZURICH = ZoneInfo("Europe/Zurich")

STALE_AFTER_HOURS = 6.0
STALE_CONFIDENCE_CAP = 0.5
CAUTION_BELOW = 0.6


@dataclass
class Framed:
    assessment: RiskAssessment
    stale_label: str | None
    framing_notes: list[str]


def apply_stage1(a: RiskAssessment, snap: WeatherSnapshot, now: datetime) -> Framed:
    age_h = (now - snap.run_time).total_seconds() / 3600
    notes: list[str] = []
    stale_label = None
    conf = a.confidence
    stale = age_h > STALE_AFTER_HOURS
    if stale:
        conf = min(conf, STALE_CONFIDENCE_CAP)
        stale_label = f"forecast from {snap.run_time.astimezone(ZURICH).strftime('%H:%M')}, {int(round(age_h))} h old"
        notes.append(f"INV-4: forecast age {age_h:.1f} h > {STALE_AFTER_HOURS:.0f} h; confidence capped at {STALE_CONFIDENCE_CAP}")
    cautionary = conf < CAUTION_BELOW
    if cautionary:
        notes.append(f"INV-5: confidence {conf} below {CAUTION_BELOW}; cautionary framing forced")
    return Framed(a.model_copy(update={"confidence": conf, "stale": stale, "cautionary": cautionary}), stale_label, notes)
