"""Template renderer (ARCHITECTURE §6.5, KAD-8). Rendered sentences are the only carriers of safety facts."""
from __future__ import annotations

import string
from dataclasses import dataclass

from pathlib import Path

from hsa.domain.models import Hazard, Recommendation
from hsa.rules.loader import Catalogue

REC_IDS = ("MIT-START-01", "MIT-TURN-01", "ALT-ROUTE-01")


def load_rec_templates(templates_dir: Path, languages=("en", "de")) -> dict[tuple[str, str], str]:
    out = {}
    for rid in REC_IDS:
        for lang in languages:
            f = Path(templates_dir) / lang / f"{rid}.txt"
            if f.exists():
                out[(rid, lang)] = f.read_text().strip()
    return out

REFERENCE_LANG = "en"
FALLBACK_NOTICE = {"de": "Dieser Hinweis ist nur auf Englisch verfügbar.", "en": "This note is only available in English."}


@dataclass
class RenderedSentence:
    kind: str
    title: str
    body: str
    provenance: str
    lang: str
    object_id: str
    fallback_notice: str | None = None


class _Safe(dict):
    def __missing__(self, k):
        raise KeyError(k)


def placeholders(template: str) -> set[str]:
    return {f for _, f, _, _ in string.Formatter().parse(template) if f}


class Renderer:
    def __init__(self, catalogue: Catalogue, rec_templates: dict[tuple[str, str], str] | None = None):
        self.cat = catalogue
        self.rec = rec_templates or {}

    def render_recommendation(self, r: Recommendation, lang: str) -> RenderedSentence:
        tpl = self.rec.get((r.provenance.rule_id, lang))
        used, notice = lang, None
        if tpl is None:
            tpl = self.rec.get((r.provenance.rule_id, REFERENCE_LANG))
            used, notice = REFERENCE_LANG, FALLBACK_NOTICE.get(lang, FALLBACK_NOTICE["en"])
        if tpl is None:
            raise LookupError(f"no template for {r.provenance.rule_id}")
        title, _, body = tpl.partition("\n")
        slots = _Safe({k: (f"{v:g}" if isinstance(v, float) else v) for k, v in r.slots.items()})
        prov = f"{r.provenance.rule_ref} · re-assessed · confidence {r.provenance.confidence:.2f}"
        return RenderedSentence(r.kind, title.format_map(slots), body.format_map(slots), prov, used, r.id, notice)

    def render_hazard(self, h: Hazard, lang: str) -> RenderedSentence:
        tpl = self.cat.template(h.provenance.rule_id, lang)
        used, notice = lang, None
        if tpl is None:
            tpl = self.cat.template(h.provenance.rule_id, REFERENCE_LANG)
            used, notice = REFERENCE_LANG, FALLBACK_NOTICE.get(lang, FALLBACK_NOTICE["en"])
        if tpl is None:
            raise LookupError(f"no template in any language for {h.provenance.rule_id}")
        title, _, body = tpl.partition("\n")
        slots = _Safe({k: (f"{v:g}" if isinstance(v, float) else v) for k, v in h.slots.items()})
        rule = self.cat.by_id(h.provenance.rule_id)
        prov = f"Rule {h.provenance.rule_ref} · {rule.basis.split(';')[0]} · confidence {h.provenance.confidence:.2f}"
        return RenderedSentence("hazard", title.format_map(slots), body.format_map(slots), prov, used, h.id, notice)
