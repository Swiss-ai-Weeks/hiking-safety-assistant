"""Output gate stage 2 (ARCHITECTURE §6.5): allowlist check on the wrapper; INV-6 and INV-7."""
from __future__ import annotations

from dataclasses import dataclass, field

from hsa.gate.phrase_bank import PhraseBank

DISCLAIMER_ID = "disclaimer.decision_support"
DISCLAIMER = {
    "en": "Decision support, not a go/no-go. Conditions change; check MeteoSwiss and the SLF bulletin before you leave. Emergency: 1414 (Rega) · 112.",
    "de": "Entscheidungshilfe, kein Go/No-Go. Bedingungen ändern sich; prüfen Sie MeteoSchweiz und das SLF-Bulletin vor dem Aufbruch. Notfall: 1414 (Rega) · 112.",
}


class Stage2Rejected(Exception):
    pass


@dataclass
class WrapperSentence:
    id: str
    text: str
    lang: str
    source: str = "phrase_bank"


@dataclass
class FinalResponse:
    sentences: list[WrapperSentence]
    disclaimer: str
    released: bool
    holds: list[str] = field(default_factory=list)


def assemble_wrapper(ids: list[str], bank: PhraseBank, lang: str) -> list[WrapperSentence]:
    out = []
    for pid in ids:
        if not bank.has(pid, lang):
            raise Stage2Rejected(f"wrapper identifier {pid!r} not in the {lang} phrase bank; rejected, not hedged")
        out.append(WrapperSentence(pid, bank.text(pid, lang), lang))
    return out


def finalize_response(sentences: list[WrapperSentence], bank: PhraseBank, lang: str) -> FinalResponse:
    disc = DISCLAIMER.get(lang, DISCLAIMER["en"])
    holds = []
    if not any(s.id == DISCLAIMER_ID for s in sentences):
        holds.append("INV-7: disclaimer block attached before release")
        sentences = [*sentences, WrapperSentence(DISCLAIMER_ID, disc, lang, source="disclaimer")]
    return FinalResponse(sentences=sentences, disclaimer=disc, released=True, holds=holds)
