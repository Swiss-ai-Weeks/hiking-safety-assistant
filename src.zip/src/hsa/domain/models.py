"""Domain spine (ARCHITECTURE §5). Static, live, derived and context planes."""
from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Literal

from pydantic import BaseModel, Field

from hsa.domain.provenance import DerivedProvenance, SourceProvenance


class Severity(StrEnum):
    NONE = "none"
    MODERATE = "moderate"
    HIGH = "high"

    @property
    def rank(self) -> int:
        return {"none": 0, "moderate": 1, "high": 2}[self.value]


class Unknown(BaseModel):
    """An attribute we could not obtain. Never falsy-as-absent; see ARCHITECTURE §8."""

    kind: Literal["unknown"] = "unknown"
    reason: str = "not available from source"


class GradeRange(BaseModel):
    low: int = Field(ge=1, le=6)
    high: int = Field(ge=1, le=6)
    exact: bool = False

    def label(self) -> str:
        return f"T{self.low}" if self.low == self.high else f"T{self.low}–T{self.high}"


class Segment(BaseModel):
    id: str
    index: int
    name: str
    coords: list[tuple[float, float]]  # (lat, lon)
    length_m: float
    ascent_m: float
    descent_m: float
    elevation_max_m: float
    place: str | None = None  # the point a hiker would name for this leg (col, hut, lake)
    place_elevation_m: float | None = None
    grade: GradeRange | Unknown = Field(default_factory=Unknown)
    exposure: bool | Unknown = Field(default_factory=Unknown)
    fixed_cables: bool | Unknown = Field(default_factory=Unknown)
    provenance: SourceProvenance | None = None


class Route(BaseModel):
    id: str
    name: str
    coords: list[tuple[float, float]]
    grade: GradeRange | Unknown = Field(default_factory=Unknown)
    length_m: float
    ascent_m: float
    segments: list[Segment] = []
    provenance: SourceProvenance | None = None


class TraversalWindow(BaseModel):
    segment_id: str
    start: datetime
    end: datetime


class HikePlan(BaseModel):
    route_id: str
    date: datetime
    start_time: datetime
    pace_factor: float = Field(default=1.25, gt=0)  # >1 is slower than the reference formula
    party_size: int = 1
    capability_grade: int | None = None  # stated T-grade capability, else conservative default


class WeatherCondition(BaseModel):
    id: str
    segment_id: str
    valid_at: datetime
    temperature_c: float | Unknown = Field(default_factory=Unknown)
    gust_kmh: float | Unknown = Field(default_factory=Unknown)
    precipitation_mm: float | Unknown = Field(default_factory=Unknown)
    cloud_base_m: float | Unknown = Field(default_factory=Unknown)
    freezing_level_m: float | Unknown = Field(default_factory=Unknown)
    cape_jkg: float | Unknown = Field(default_factory=Unknown)
    provenance: SourceProvenance


class Hazard(BaseModel):
    id: str
    segment_id: str
    category: str
    severity: Severity
    window_start: datetime
    window_end: datetime
    slots: dict[str, str | float | int] = {}
    provenance: DerivedProvenance
    subordinated_to_warning: str | None = None


class Recommendation(BaseModel):
    id: str
    kind: Literal["mitigation", "alternative"]
    justifies: list[str] = Field(min_length=1)  # hazard ids (INV-1)
    slots: dict[str, str | float | int] = {}
    provenance: DerivedProvenance


class RiskAssessment(BaseModel):
    id: str
    route_id: str
    hazards: list[Hazard]
    recommendations: list[Recommendation] = []
    severity: Severity
    confidence: float = Field(ge=0.0, le=1.0)
    evidence_ids: list[str]
    reasoning_trace: list[str]
    stale: bool = False
    cautionary: bool = False
