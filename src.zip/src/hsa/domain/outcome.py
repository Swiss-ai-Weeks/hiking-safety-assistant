"""Assessment outcome by rule-evaluation coverage (ARCHITECTURE §8; CONTEXT: Assessment outcome)."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum

from hsa.adapters.interfaces import Unresolved
from hsa.domain.models import HikePlan, Route, Unknown

DEFAULT_CAPABILITY_GRADE = 2  # conservative default: T2 when the hiker states nothing (FR-9)
RULE_CONSUMED_ATTRIBUTES = {"exposure"}  # segment attributes any catalogue rule consumes


class Outcome(StrEnum):
    NOT_ASSESSABLE = "not_assessable"
    PARTIALLY_ASSESSED = "partially_assessed"
    ASSESSED = "assessed"


@dataclass
class Classification:
    outcome: Outcome
    reason: str = ""
    not_evaluated: list[tuple[str, str, list[str]]] = field(default_factory=list)
    not_available: list[str] = field(default_factory=list)
    assumed_capability: int | None = None
    assumed_capability_note: str = ""

    @property
    def show_nothing_flagged(self) -> bool:
        return self.outcome == Outcome.ASSESSED


def classify(route, plan: HikePlan, fusion, snapshot, fatal: str | None,
             consumed_attributes: set[str] = RULE_CONSUMED_ATTRIBUTES) -> Classification:
    if isinstance(route, Unresolved) or route is None:
        return Classification(Outcome.NOT_ASSESSABLE, reason=f"Route could not be resolved on the official network: {getattr(route, 'reason', 'unknown')}")
    if snapshot is None or fusion is None:
        return Classification(Outcome.NOT_ASSESSABLE, reason="The MeteoSwiss weather source is unavailable for this route and time.")
    if fatal:
        return Classification(Outcome.NOT_ASSESSABLE, reason=f"A fusion post-condition failed ({fatal}).")
    c = Classification(Outcome.ASSESSED)
    if plan.capability_grade is None:
        c.assumed_capability = DEFAULT_CAPABILITY_GRADE
        c.assumed_capability_note = f"Your ability. We assumed T{DEFAULT_CAPABILITY_GRADE} until you tell us."
    for seg in route.segments:
        for attr in ("grade", "exposure", "fixed_cables"):
            if isinstance(getattr(seg, attr), Unknown) and attr not in consumed_attributes:
                c.not_available.append(f"{seg.name}: {attr}")
    if fusion.coverage.not_evaluated:
        c.outcome = Outcome.PARTIALLY_ASSESSED
        c.not_evaluated = list(fusion.coverage.not_evaluated)
        c.reason = "Some hazard rules could not be evaluated on some segments."
    return c
