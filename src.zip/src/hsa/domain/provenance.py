"""Provenance: every fact carries it (ARCHITECTURE §3, CONTEXT: Source fact and derived fact)."""
from __future__ import annotations

from datetime import datetime, timedelta

from pydantic import BaseModel, Field


class SourceProvenance(BaseModel):
    """Source fact: taken from swisstopo or MeteoSwiss."""

    kind: str = Field(default="source", frozen=True)
    source: str = Field(min_length=1)
    observed_at: datetime
    confidence: float = Field(ge=0.0, le=1.0)

    def freshness_at(self, now: datetime) -> timedelta:
        return now - self.observed_at


class DerivedProvenance(BaseModel):
    """Derived fact: computed by the fusion engine from input facts through one hazard rule."""

    kind: str = Field(default="derived", frozen=True)
    input_fact_ids: list[str] = Field(min_length=1)
    rule_id: str = Field(min_length=1)
    rule_version: int = Field(ge=1)
    confidence: float = Field(ge=0.0, le=1.0)

    @property
    def rule_ref(self) -> str:
        return f"{self.rule_id} v{self.rule_version}"
