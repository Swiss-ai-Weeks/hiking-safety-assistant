from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Session:
    id: str
    plan: dict = field(default_factory=dict)
    messages: list[dict] = field(default_factory=list)
    turns: int = 0

    def remember_plan(self, plan: dict) -> None:
        self.plan.update(plan)

    def append(self, role: str, content) -> None:
        self.messages.append({"role": role, "content": content})
        if role == "user":
            self.turns += 1


class SessionStore:
    def __init__(self) -> None:
        self._s: dict[str, Session] = {}

    def get(self, sid: str) -> Session:
        return self._s.setdefault(sid, Session(id=sid))
