"""Planner tool definitions (ARCHITECTURE §6.1). Strict schemas; the model may only act through these."""
from __future__ import annotations


def _tool(name: str, description: str, props: dict, required: list[str]) -> dict:
    return {"name": name, "description": description, "strict": True,
            "input_schema": {"type": "object", "properties": props, "required": required, "additionalProperties": False}}


TOOLS = [
    _tool("resolve_route", "Resolve a hike to an official swisstopo network route by name, or by start and end coordinates.",
          {"query": {"type": "string", "description": "Route name as the user said it, or 'lat,lon -> lat,lon'"}}, ["query"]),
    _tool("assess_plan", "Run the deterministic risk fusion for a resolved route on a date and start time. Returns an assessment id and outcome.",
          {"route_id": {"type": "string"}, "date": {"type": "string", "description": "YYYY-MM-DD"},
           "start_time": {"type": "string", "description": "HH:MM local"},
           "pace_factor": {"type": ["number", "null"], "description": "1.0 reference pace; 1.25 cautious default"},
           "capability_grade": {"type": ["integer", "null"], "description": "Stated T-grade ability 1-6, or null"}},
          ["route_id", "date", "start_time", "pace_factor", "capability_grade"]),
    _tool("get_alternatives", "Compute mitigations and alternative routes for an assessment.", {"assessment_id": {"type": "string"}}, ["assessment_id"]),
    _tool("lookup_corpus", "Retrieve verbatim guidance passages (hiking scale, huts, safety guidance) shown to the user with citation.",
          {"query": {"type": "string"}}, ["query"]),
    _tool("select_phrases", "Choose the conversational wrapper sentences by identifier from the approved phrase bank. Only these identifiers reach the user.",
          {"ids": {"type": "array", "items": {"type": "string"}}}, ["ids"]),
]

SYSTEM = """You are the query planner for a Swiss hiking safety assistant. You never write text for the user.
Your only outputs are tool calls. Plan: resolve the route, assess the plan, fetch alternatives when hazards are flagged,
look up guidance passages when the user asks what a term means, then call select_phrases once with the wrapper sentence
identifiers that fit. Every fact the user sees is rendered by the system from templates; anything you write as text is discarded."""
