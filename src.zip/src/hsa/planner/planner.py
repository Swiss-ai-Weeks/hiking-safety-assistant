"""Claude query planner (ARCHITECTURE §6.1, KAD-8). Model: claude-opus-5, adaptive thinking, strict tools.

The model emits tool calls only. Text blocks are counted and discarded; they never reach the user.
Phrase identifiers are validated against the phrase bank; unknown ids are rejected and recorded.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Callable

from hsa.planner.session import Session
from hsa.planner.tools import SYSTEM, TOOLS

MODEL = "claude-opus-5"
Executor = Callable[[str, dict], Any]


@dataclass
class PlannerOutput:
    tool_calls: list[str] = field(default_factory=list)
    phrase_ids: list[str] = field(default_factory=list)
    rejected_phrase_ids: list[str] = field(default_factory=list)
    discarded_text_blocks: int = 0
    results: dict[str, Any] = field(default_factory=dict)
    model: str = ""


class Planner:
    def __init__(self, client, execute: Executor, phrase_ids: list[str], model: str = MODEL, max_turns: int = 8):
        self.client, self.execute, self.allowed, self.model, self.max_turns = client, execute, set(phrase_ids), model, max_turns

    def plan(self, user_text: str, session: Session) -> PlannerOutput:
        out = PlannerOutput()
        session.append("user", user_text)
        for _ in range(self.max_turns):
            resp = self.client.messages.create(
                model=self.model, max_tokens=4096, system=SYSTEM, tools=TOOLS, tool_choice={"type": "auto"},
                thinking={"type": "adaptive"}, messages=session.messages)
            out.model = getattr(resp, "model", self.model)
            tool_results = []
            for block in resp.content:
                if block.type == "text":
                    out.discarded_text_blocks += 1
                elif block.type == "tool_use":
                    args = block.input if isinstance(block.input, dict) else json.loads(block.input)
                    out.tool_calls.append(block.name)
                    if block.name == "select_phrases":
                        for pid in args.get("ids", []):
                            (out.phrase_ids if pid in self.allowed else out.rejected_phrase_ids).append(pid)
                        result = {"accepted": [p for p in args.get("ids", []) if p in self.allowed]}
                    else:
                        result = self.execute(block.name, args)
                        out.results[block.name] = result
                        if block.name == "assess_plan":
                            session.remember_plan({k: args.get(k) for k in ("route_id", "date", "start_time")})
                    tool_results.append({"type": "tool_result", "tool_use_id": block.id, "content": json.dumps(result, default=str)})
            session.append("assistant", [self._to_param(b) for b in resp.content if b.type != "text"] or [{"type": "text", "text": "(planning)"}])
            if resp.stop_reason != "tool_use" or not tool_results:
                break
            session.append("user", tool_results)
            session.turns -= 1  # tool results are not user turns
        return out

    @staticmethod
    def _to_param(b) -> dict:
        if b.type == "tool_use":
            return {"type": "tool_use", "id": b.id, "name": b.name, "input": b.input}
        return {"type": b.type}
