---
source: SAC hiking scale (Berg- und Alpinwandern Skala), summarised from the Swiss Alpine Club grading, 2020 edition
---
## T1 Hiking
Trail well marked and cleared. Terrain flat or slightly sloping, no risk of falling. Ordinary trainers are adequate; orientation is easy even without a map.

## T2 Mountain hiking
Trail with continuous line and balanced ascents. Terrain partly steep; risk of falling not excluded. Hiking shoes with a good grip are recommended; basic orientation skills needed.

## T3 Demanding mountain hiking
Trail not always visible on the ground; exposed sections may be secured with ropes or chains and hands may be needed for balance. Partly exposed with a risk of falling, scree, and pathless rock. Sure-footedness, good hiking boots, and average orientation skills are required.

## T4 Alpine hiking
Trail traces not always present; hands are needed to progress in places. Terrain quite exposed, steep grass slopes, easy snow fields and glacier passages without crevasses. Familiarity with exposed terrain, sturdy boots, and good route-finding skills are required.

## T5 Demanding alpine hiking
Often pathless, with individual easy climbing sections. Exposed and demanding terrain, steep scree, glaciers and snow fields with a risk of slipping. Mountaineering boots, reliable route-finding, and good alpine experience are required.

## T6 Difficult alpine hiking
Mostly pathless, with climbing sections up to grade II. Often very exposed, precarious jagged rock, glaciers with a risk of slipping. Excellent orientation skills and mature alpine experience are required; usually not marked.
