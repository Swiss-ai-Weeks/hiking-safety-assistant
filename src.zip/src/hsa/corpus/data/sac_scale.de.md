---
source: SAC Berg- und Alpinwanderskala, zusammengefasst nach der Einstufung des Schweizer Alpen-Clubs, Ausgabe 2020
---
## T1 Wandern
Weg gut gebahnt und markiert. Gelände flach oder leicht geneigt, keine Absturzgefahr. Turnschuhe genügen; Orientierung auch ohne Karte problemlos.

## T2 Bergwandern
Weg mit durchgehendem Trassee und ausgeglichenen Steigungen. Gelände teilweise steil; Absturzgefahr nicht ausgeschlossen. Trekkingschuhe empfohlen; elementares Orientierungsvermögen nötig.

## T3 Anspruchsvolles Bergwandern
Weg am Boden nicht unbedingt sichtbar; ausgesetzte Stellen können mit Seilen oder Ketten gesichert sein, die Hände werden eventuell zum Halten des Gleichgewichts gebraucht. Teilweise exponiert mit Absturzgefahr, Geröllflächen, weglose Schrofen. Gute Trittsicherheit, gute Trekkingschuhe und durchschnittliches Orientierungsvermögen erforderlich.

## T4 Alpinwandern
Wegspur nicht zwingend vorhanden; an gewissen Stellen braucht es die Hände zum Vorwärtskommen. Gelände bereits recht exponiert, heikle Grashalden, einfache Firnfelder und apere Gletscherpassagen. Vertrautheit mit exponiertem Gelände, stabile Trekkingschuhe und gute Geländebeurteilung erforderlich.

## T5 Anspruchsvolles Alpinwandern
Oft weglos, einzelne einfache Kletterstellen. Exponiert, anspruchsvolles Gelände, steile Schrofen, Gletscher und Firnfelder mit Ausgleitgefahr. Bergschuhe, sichere Geländebeurteilung und gute alpine Erfahrung erforderlich.

## T6 Schwieriges Alpinwandern
Meist weglos, Kletterstellen bis II. Häufig sehr exponiert, heikles Schrofengelände, Gletscher mit Ausgleitgefahr. Ausgezeichnetes Orientierungsvermögen und ausgereifte alpine Erfahrung erforderlich; meist nicht markiert.
