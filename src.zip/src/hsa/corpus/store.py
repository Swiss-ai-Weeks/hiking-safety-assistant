"""Retrieval corpus served as verbatim cited excerpts (ARCHITECTURE §6.2, KAD-8). Keyword lookup is enough for the slice."""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path


@dataclass(frozen=True)
class Chunk:
    chunk_id: str
    lang: str
    heading: str
    text: str
    source: str


@dataclass(frozen=True)
class CitedExcerpt:
    chunk_id: str
    text: str
    heading: str
    source: str
    retrieved_at: datetime
    lang: str


def _tokens(s: str) -> set[str]:
    return set(re.findall(r"[a-zäöüéèàß0-9]+", s.lower()))


class CorpusStore:
    def __init__(self, chunks: list[Chunk]):
        self._chunks = {c.chunk_id: c for c in chunks}

    @classmethod
    def load(cls, folder: Path) -> "CorpusStore":
        chunks: list[Chunk] = []
        for f in sorted(Path(folder).glob("*.md")):
            lang = f.suffixes[-2].lstrip(".") if len(f.suffixes) >= 2 else "en"
            text = f.read_text()
            source = "corpus"
            m = re.match(r"---\n(.*?)\n---\n", text, flags=re.S)
            if m:
                for line in m.group(1).splitlines():
                    if line.startswith("source:"):
                        source = line.split(":", 1)[1].strip()
                text = text[m.end():]
            for i, part in enumerate(re.split(r"\n(?=## )", text.strip())):
                if not part.strip():
                    continue
                heading, _, body = part.partition("\n")
                heading = heading.lstrip("# ").strip()
                chunks.append(Chunk(f"{f.stem}#{i}", lang, heading, f"{heading}\n{body.strip()}", source))
        return cls(chunks)

    def chunk(self, chunk_id: str) -> Chunk:
        return self._chunks[chunk_id]

    def lookup(self, query: str, lang: str = "en", limit: int = 2) -> list[CitedExcerpt]:
        q = _tokens(query)
        scored = []
        for c in self._chunks.values():
            if c.lang != lang:
                continue
            words = _tokens(c.heading) | _tokens(c.text)
            score = len(q & words) + 3 * len(q & _tokens(c.heading))
            if score > 0:
                scored.append((score, c))
        scored.sort(key=lambda x: -x[0])
        now = datetime.now(timezone.utc)
        return [CitedExcerpt(c.chunk_id, c.text, c.heading, c.source, now, c.lang) for _, c in scored[:limit]]
