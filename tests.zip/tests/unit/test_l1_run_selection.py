from datetime import datetime, timedelta, timezone

from hsa.adapters.meteoswiss import CH1, CH2, select_collection_for

REF = datetime(2026, 9, 14, 15, 0, tzinfo=timezone.utc)


def test_collection_chosen_by_horizon_from_run_reference_not_from_now():
    hours = [REF + timedelta(hours=h) for h in (30, 33)]
    assert select_collection_for(REF, hours) == CH1
    hours = [REF + timedelta(hours=h) for h in (30, 40)]
    assert select_collection_for(REF, hours) == CH2
    assert select_collection_for(REF, [REF + timedelta(hours=130)]) is None
