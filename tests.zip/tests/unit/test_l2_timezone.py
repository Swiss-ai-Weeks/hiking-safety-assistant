from datetime import timezone

from hsa.api.pipeline import ZURICH, local_start, demo_pipeline


def test_plan_start_is_swiss_local_time_and_converts_to_utc():
    dt = local_start("2026-09-15", "07:30")
    assert dt.tzinfo is not None and dt.strftime("%H:%M") == "07:30"
    assert dt.astimezone(timezone.utc).strftime("%H:%M") == "05:30"  # CEST in September


def test_rendered_times_are_local_even_when_conditions_are_utc():
    v = demo_pipeline().assess("Oeschinensee → Blüemlisalphütte", "2026-09-19", "07:30", lang="en")
    assert v["timeline"][0]["time"] == "07:30"
    assert v["route"]["start"] == "07:30"
