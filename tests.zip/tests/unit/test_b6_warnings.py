from hsa.adapters.warnings import UnavailableWarnings, WarningsStatus


def test_warnings_source_reports_unavailable_with_reason():
    st = UnavailableWarnings().fetch(region="Bernese Alps")
    assert isinstance(st, WarningsStatus) and st.available is False
    assert "no stable" in st.reason.lower() or "unavailable" in st.reason.lower()


def test_unavailable_warnings_yield_disclosure_object_not_empty_list():
    st = UnavailableWarnings().fetch(region="x")
    assert st.warnings == [] and st.disclosure
    assert any("MeteoSwiss" in c.label for c in st.channels) and any("SLF" in c.label for c in st.channels)
