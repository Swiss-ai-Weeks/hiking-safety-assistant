from hsa.adapters.interfaces import Unresolved
from hsa.adapters.swisstopo import FRIENDLY_ROUTES, SwisstopoClient


def test_friendly_name_resolves_via_start_end_points_on_the_network():
    c = SwisstopoClient.__new__(SwisstopoClient)
    calls = []
    c.find_wanderland = lambda title: calls.append(("find", title)) or []
    c.resolve_by_points = lambda start, end: calls.append(("points", start, end)) or Unresolved(reason="stub")
    out = c.resolve_by_name("Oeschinensee → Blüemlisalphütte")
    assert ("find", "Oeschinensee → Blüemlisalphütte") in calls
    assert any(k[0] == "points" and k[1] == FRIENDLY_ROUTES["oeschinensee → blüemlisalphütte"][0] for k in calls)
    assert isinstance(out, Unresolved)


def test_unknown_friendly_name_still_unresolved_with_reason():
    c = SwisstopoClient.__new__(SwisstopoClient)
    c.find_wanderland = lambda title: []
    out = c.resolve_by_name("Nowhere Ridge")
    assert isinstance(out, Unresolved) and "Nowhere Ridge" in out.reason
