from datetime import date, datetime, timedelta, timezone

from hsa.weather.snapshot import SnapshotKey, SnapshotStore, WeatherSnapshot

T0 = datetime(2026, 9, 18, 21, 0, tzinfo=timezone.utc)


def key(**kw):
    base = dict(route_id="r1", hike_date=date(2026, 9, 19), start_hour=7, pace_factor=1.25, forecast_window="ch1")
    base.update(kw)
    return SnapshotKey(**base)


def make(k, fetched=T0):
    return WeatherSnapshot(key=k, fetched_at=fetched, run_time=T0 - timedelta(hours=1), conditions=[], ttl=timedelta(hours=3))


def test_snapshot_key_is_route_date_forecast_window():
    assert key() == key()
    assert key(route_id="r2") != key()
    assert key(hike_date=date(2026, 9, 20)) != key()


def test_changing_start_time_invalidates_snapshot():
    store = SnapshotStore()
    store.put(make(key()))
    assert store.get_valid_or_none(key(), now=T0) is not None
    assert store.get_valid_or_none(key(start_hour=6), now=T0) is None


def test_expired_ttl_invalidates_snapshot():
    store = SnapshotStore()
    store.put(make(key()))
    assert store.get_valid_or_none(key(), now=T0 + timedelta(hours=2)) is not None
    assert store.get_valid_or_none(key(), now=T0 + timedelta(hours=4)) is None


def test_snapshot_is_never_persisted():
    assert not hasattr(WeatherSnapshot, "save") and not hasattr(SnapshotStore, "to_disk")
    store = SnapshotStore()
    assert store.backend == "memory"
