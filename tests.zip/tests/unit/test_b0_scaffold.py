import pytest


def test_package_imports():
    import hsa

    assert hsa.__version__ == "0.1.0"


@pytest.mark.live
def test_live_marker_skipped_by_default():
    raise AssertionError("must be skipped unless LIVE=1")
