from datetime import timedelta
from pathlib import Path

from hsa.adapters.warnings import UnavailableWarnings
from hsa.domain.models import Severity
from hsa.fusion.confidence import condition_confidence
from hsa.fusion.engine import FusionEngine
from hsa.rules.loader import load_catalogue
from tests.fakes.scenario import RUN, demo_route, plan, snapshot

ROOT = Path(__file__).resolve().parents[2]
CAT = load_catalogue(ROOT / "src/hsa/rules/rules", ROOT / "templates")


def test_exposed_segment_with_high_gust_in_window_yields_hazard_with_rule_id_and_inputs():
    route, p = demo_route(), plan()
    snap = snapshot(route, p, gust_by_segment={2: 55.0})
    res = FusionEngine(CAT).assess(route, p, snap, UnavailableWarnings().fetch("x"), now=RUN + timedelta(hours=1))
    wind = [h for h in res.assessment.hazards if h.category == "wind"]
    assert wind and wind[0].severity == Severity.HIGH
    assert wind[0].provenance.rule_id == "WIND-EXP-02" and wind[0].provenance.rule_version == 3
    assert any(i.startswith("wc:2:") for i in wind[0].provenance.input_fact_ids)
    assert wind[0].segment_id == route.segments[2].id


def test_hazard_confidence_falls_with_data_age_and_lead_time():
    fresh = condition_confidence(source_confidence=0.85, data_age=timedelta(hours=1), lead_time=timedelta(hours=5))
    old = condition_confidence(source_confidence=0.85, data_age=timedelta(hours=9), lead_time=timedelta(hours=5))
    far = condition_confidence(source_confidence=0.85, data_age=timedelta(hours=1), lead_time=timedelta(hours=60))
    assert fresh > old and fresh > far and 0 < far < 1


def test_assessment_aggregates_hazards_and_carries_reasoning_trace_from_derived_provenance():
    route, p = demo_route(), plan()
    snap = snapshot(route, p, gust_by_segment={2: 55.0, 1: 35.0}, temp=-1.0)  # WIND-EXP-02 on seg 2, COLD-01 on segs 1 and 2
    res = FusionEngine(CAT).assess(route, p, snap, UnavailableWarnings().fetch("x"), now=RUN + timedelta(hours=1))
    a = res.assessment
    assert a.severity == Severity.HIGH and len(a.hazards) >= 2
    assert all(any(h.provenance.rule_ref in line for line in a.reasoning_trace) for h in a.hazards)
    assert set(a.evidence_ids) >= {i for h in a.hazards for i in h.provenance.input_fact_ids}
    assert res.coverage.rules_total > 0 and res.coverage.not_evaluated == []
