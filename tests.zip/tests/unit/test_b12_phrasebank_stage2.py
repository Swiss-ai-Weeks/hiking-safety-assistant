from pathlib import Path

import pytest

from hsa.gate.phrase_bank import PhraseBank, PhraseBankError, review_phrases
from hsa.gate.stage2 import DISCLAIMER_ID, Stage2Rejected, assemble_wrapper, finalize_response

ROOT = Path(__file__).resolve().parents[2]
BANK = PhraseBank.load(ROOT / "phrasebank")


def test_stage2_rejects_sentence_not_in_phrase_bank():
    with pytest.raises(Stage2Rejected):
        assemble_wrapper(["ack.plan_received", "made-up.free-prose"], BANK, "en")
    ok = assemble_wrapper(["ack.plan_received", "offer.alternatives"], BANK, "en")
    assert len(ok) == 2 and all(s.source == "phrase_bank" for s in ok)


def test_INV6_phrase_bank_review_fails_on_verdict_pattern():
    with pytest.raises(PhraseBankError) as e:
        review_phrases({"bad.one": "You are good to go, the ridge is safe."}, lang="en")
    assert "good to go" in str(e.value) or "safe" in str(e.value)
    with pytest.raises(PhraseBankError):
        review_phrases({"bad.two": "Expect gusts of 60 km/h on the ridge."}, lang="en")  # controlled vocabulary + number
    review_phrases({"ok": "Here is what we checked for your plan."}, lang="en")


def test_INV7_response_held_until_disclaimer_block_attached():
    body = assemble_wrapper(["ack.plan_received"], BANK, "en")
    resp = finalize_response(body, BANK, "en")
    assert resp.released and any(s.id == DISCLAIMER_ID for s in resp.sentences)
    assert "1414" in resp.disclaimer and "112" in resp.disclaimer


def test_wrapper_assembly_from_identifiers_yields_only_bank_sentences():
    ids = ["ack.plan_received", "orient.crux_first", "offer.alternatives"]
    out = assemble_wrapper(ids, BANK, "de")
    assert [s.id for s in out] == ids and all(s.lang == "de" for s in out)
    assert all(s.text == BANK.text(s.id, "de") for s in out)
