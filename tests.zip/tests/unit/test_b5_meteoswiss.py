from datetime import datetime, timedelta, timezone
from pathlib import Path

from hsa.adapters.meteoswiss import GribField, choose_collection, conditions_from_fields
from hsa.domain.models import Unknown
from tests.fakes.scenario import demo_route, plan

FIX = Path(__file__).resolve().parents[1] / "fixtures" / "grib"
RUN = datetime(2026, 9, 19, 6, 0, tzinfo=timezone.utc)


def test_selects_ch1_within_33h_and_ch2_beyond():
    assert choose_collection(timedelta(hours=10)) == "ch.meteoschweiz.ogd-forecasting-icon-ch1"
    assert choose_collection(timedelta(hours=33)) == "ch.meteoschweiz.ogd-forecasting-icon-ch1"
    assert choose_collection(timedelta(hours=34)) == "ch.meteoschweiz.ogd-forecasting-icon-ch2"
    assert choose_collection(timedelta(hours=121)) is None


def test_extracts_condition_per_segment_per_hour_from_fixture():
    route, p = demo_route(), plan()
    fields = {
        RUN + timedelta(hours=h): {"T_2M": GribField.load(FIX / "T_2M.grib2"), "VMAX_10M": GribField.load(FIX / "VMAX_10M.grib2"),
                                   "TOT_PREC": GribField.load(FIX / "TOT_PREC.grib2"), "HZEROCL": GribField.load(FIX / "HZEROCL.grib2")}
        for h in range(2, 6)
    }
    conds = conditions_from_fields(route.segments, fields, run_time=RUN)
    assert len(conds) == 3 * 4
    ridge = [c for c in conds if c.segment_id == route.segments[2].id]
    lake = [c for c in conds if c.segment_id == route.segments[0].id]
    assert all(abs(c.temperature_c - 4.0) < 0.1 for c in conds)
    assert all(c.gust_kmh > 55 for c in ridge) and all(c.gust_kmh < 25 for c in lake)
    assert all(c.freezing_level_m == 2900.0 for c in conds)
    assert all(c.provenance.source.startswith("meteoswiss") and c.provenance.observed_at == RUN for c in conds)


def test_missing_variable_marks_condition_field_not_evaluated():
    route = demo_route()
    fields = {RUN + timedelta(hours=2): {"T_2M": GribField.load(FIX / "T_2M.grib2")}}
    conds = conditions_from_fields(route.segments, fields, run_time=RUN)
    assert all(isinstance(c.gust_kmh, Unknown) and isinstance(c.cape_jkg, Unknown) for c in conds)
    assert all(not isinstance(c.temperature_c, Unknown) for c in conds)
