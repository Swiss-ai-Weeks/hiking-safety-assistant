from hsa.planner.planner import Planner
from hsa.planner.session import SessionStore
from hsa.planner.tools import TOOLS
from tests.fakes.anthropic import FakeAnthropic, planning_script


def executor_factory(log):
    def execute(name, args):
        log.append((name, args))
        return {"resolve_route": {"route_id": "wanderland:fixture:oeschinensee-bluemlisalp", "name": "Oeschinensee → Blüemlisalphütte"},
                "assess_plan": {"assessment_id": "ra:1", "outcome": "assessed", "hazards": 2},
                "get_alternatives": {"count": 1}, "lookup_corpus": {"excerpts": []}}.get(name, {})
    return execute


def test_planner_calls_resolve_route_then_assess_for_a_planning_question():
    log = []
    p = Planner(FakeAnthropic(planning_script()), executor_factory(log), phrase_ids=["ack.plan_received", "orient.crux_first", "offer.alternatives"])
    out = p.plan("Can I do Oeschinensee to the Blüemlisalphütte on Saturday, starting 7:30?", SessionStore().get("s1"))
    assert [n for n, _ in log][:2] == ["resolve_route", "assess_plan"]
    assert out.phrase_ids == ["ack.plan_received", "orient.crux_first", "offer.alternatives"]


def test_planner_output_is_only_tool_calls_and_phrase_ids_never_free_text_to_user():
    p = Planner(FakeAnthropic(planning_script()), executor_factory([]), phrase_ids=["ack.plan_received", "orient.crux_first", "offer.alternatives"])
    out = p.plan("question", SessionStore().get("s2"))
    assert not hasattr(out, "text")
    assert out.discarded_text_blocks == 3  # every LLM text block was dropped, including the reassurance
    assert all(n in {t["name"] for t in TOOLS} for n in out.tool_calls)


def test_planner_rejects_unknown_phrase_id_from_model():
    script = planning_script()
    script[2].content[0].input = {"ids": ["ack.plan_received", "made.up"]}
    p = Planner(FakeAnthropic(script), executor_factory([]), phrase_ids=["ack.plan_received"])
    out = p.plan("q", SessionStore().get("s3"))
    assert out.phrase_ids == ["ack.plan_received"] and out.rejected_phrase_ids == ["made.up"]


def test_session_retains_hike_plan_across_turns():
    store = SessionStore()
    s = store.get("abc")
    s.remember_plan({"route_id": "r1", "date": "2026-09-19", "start_time": "07:30"})
    s2 = store.get("abc")
    assert s2.plan["route_id"] == "r1" and s2.turns == 0
    s2.append("user", "what about 6:30?")
    assert store.get("abc").turns == 1


def test_tools_are_strict_with_closed_schemas():
    for t in TOOLS:
        assert t["strict"] is True and t["input_schema"]["additionalProperties"] is False and "required" in t["input_schema"]
