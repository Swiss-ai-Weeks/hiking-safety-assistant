from datetime import timedelta
from pathlib import Path

from hsa.adapters.warnings import Channel, OfficialWarning, UnavailableWarnings, WarningsStatus
from hsa.domain.models import Recommendation
from hsa.domain.provenance import DerivedProvenance
from hsa.fusion.engine import FusionEngine
from hsa.fusion.post_conditions import apply_post_conditions
from hsa.rules.loader import load_catalogue
from tests.fakes.scenario import RUN, demo_route, plan, snapshot

ROOT = Path(__file__).resolve().parents[2]
CAT = load_catalogue(ROOT / "src/hsa/rules/rules", ROOT / "templates")


def _assess(warnings=None):
    route, p = demo_route(), plan()
    snap = snapshot(route, p, gust_by_segment={2: 55.0})
    w = warnings or UnavailableWarnings().fetch("x")
    return FusionEngine(CAT).assess(route, p, snap, w, now=RUN + timedelta(hours=1)), snap


def _rec(justifies, rid="rec:1"):
    return Recommendation(id=rid, kind="mitigation", justifies=justifies,
                          provenance=DerivedProvenance(input_fact_ids=["ra:x"], rule_id="MIT-START", rule_version=1, confidence=0.7))


def test_INV1_recommendation_without_justifying_hazard_is_dropped():
    res, snap = _assess()
    good = _rec([res.assessment.hazards[0].id], "rec:good")
    bad = _rec(["hz:DOES-NOT-EXIST"], "rec:bad")
    out = apply_post_conditions(res.assessment, [good, bad], res.warnings, known_fact_ids={c.id for c in snap.conditions})
    assert out.fatal is None
    assert [r.id for r in out.assessment.recommendations] == ["rec:good"]
    assert any("INV-1" in r for r in out.repairs)


def test_INV2_official_warning_subordinates_derived_hazard_in_same_category():
    w = WarningsStatus(available=True, channels=[Channel(label="MeteoSwiss warnings", href="x")], warnings=[
        OfficialWarning(id="ms:wind:1", category="wind", level=3, valid_from="2026-09-19T09:00Z", valid_to="2026-09-19T18:00Z", source="MeteoSwiss")])
    res, snap = _assess(w)
    out = apply_post_conditions(res.assessment, [], w, known_fact_ids={c.id for c in snap.conditions})
    wind = [h for h in out.assessment.hazards if h.category == "wind"]
    assert wind and wind[0].subordinated_to_warning == "ms:wind:1"
    assert any("INV-2" in r for r in out.repairs)


def test_INV2_is_inert_when_warnings_unavailable_and_disclosure_present():
    res, snap = _assess()
    out = apply_post_conditions(res.assessment, [], res.warnings, known_fact_ids={c.id for c in snap.conditions})
    assert all(h.subordinated_to_warning is None for h in out.assessment.hazards)
    assert out.disclosures and "could not be checked" in out.disclosures[0]


def test_INV3_assessment_with_evidence_free_hazard_is_not_produced():
    res, snap = _assess()
    # simulate a hazard whose evidence ids are not known facts
    h = res.assessment.hazards[0].model_copy(update={"provenance": res.assessment.hazards[0].provenance.model_copy(update={"input_fact_ids": ["ghost:1"]})})
    a = res.assessment.model_copy(update={"hazards": [h]})
    out = apply_post_conditions(a, [], res.warnings, known_fact_ids={c.id for c in snap.conditions})
    assert out.fatal is not None and "INV-3" in out.fatal and out.assessment is None
