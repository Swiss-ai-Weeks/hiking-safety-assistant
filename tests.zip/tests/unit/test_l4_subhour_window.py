from datetime import datetime, timedelta, timezone
from pathlib import Path

from hsa.adapters.warnings import UnavailableWarnings
from hsa.fusion.engine import FusionEngine
from hsa.rules.loader import load_catalogue
from tests.fakes.scenario import RUN, demo_route, plan, snapshot

ROOT = Path(__file__).resolve().parents[2]
CAT = load_catalogue(ROOT / "src/hsa/rules/rules", ROOT / "templates")


def test_segment_whose_window_has_no_whole_hour_boundary_still_gets_that_hours_condition():
    route = demo_route()
    p = plan(start=datetime(2026, 9, 19, 7, 2, 47, 123456, tzinfo=timezone.utc), pace=0.15)  # very fast: sub-hour legs
    snap = snapshot(route, p, gust_by_segment={2: 55.0})
    res = FusionEngine(CAT).assess(route, p, snap, UnavailableWarnings().fetch("x"), now=RUN + timedelta(hours=1))
    assert not [x for x in res.coverage.not_evaluated if x[2] == ["weather"]], res.coverage.not_evaluated
