from pathlib import Path

from hsa.corpus.store import CorpusStore

ROOT = Path(__file__).resolve().parents[2]
STORE = CorpusStore.load(ROOT / "src/hsa/corpus/data")


def test_lookup_returns_verbatim_passage_with_source_and_timestamp():
    hits = STORE.lookup("what does T3 mean", lang="en", limit=1)
    assert hits and "T3" in hits[0].text
    assert hits[0].source and hits[0].retrieved_at and hits[0].chunk_id


def test_excerpt_text_is_byte_identical_to_corpus_chunk():
    hit = STORE.lookup("T3", lang="en", limit=1)[0]
    assert hit.text == STORE.chunk(hit.chunk_id).text


def test_no_match_returns_empty_not_generated_text():
    assert STORE.lookup("quantum chromodynamics", lang="en", limit=3) == []
