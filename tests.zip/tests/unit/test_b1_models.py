from datetime import datetime, timezone

import pytest
from pydantic import ValidationError

from hsa.domain.models import Hazard, Severity
from hsa.domain.provenance import DerivedProvenance, SourceProvenance

NOW = datetime(2026, 9, 19, 6, 40, tzinfo=timezone.utc)


def test_source_provenance_requires_source_and_timestamp():
    ok = SourceProvenance(source="meteoswiss:icon-ch1", observed_at=NOW, confidence=0.8)
    assert ok.freshness_at(NOW).total_seconds() == 0
    with pytest.raises(ValidationError):
        SourceProvenance(source="", observed_at=NOW, confidence=0.8)
    with pytest.raises(ValidationError):
        SourceProvenance(source="x", confidence=0.8)  # type: ignore[call-arg]


def test_derived_provenance_requires_inputs_rule_id_and_version():
    ok = DerivedProvenance(input_fact_ids=["wc:1", "seg:3"], rule_id="WIND-EXP-02", rule_version=3,
                           confidence=0.7)
    assert ok.rule_ref == "WIND-EXP-02 v3"
    with pytest.raises(ValidationError):
        DerivedProvenance(input_fact_ids=[], rule_id="WIND-EXP-02", rule_version=3, confidence=0.7)
    with pytest.raises(ValidationError):
        DerivedProvenance(input_fact_ids=["a"], rule_id="", rule_version=3, confidence=0.7)


def test_hazard_cannot_be_built_without_derived_provenance():
    src = SourceProvenance(source="s", observed_at=NOW, confidence=0.9)
    with pytest.raises(ValidationError):
        Hazard(id="h1", segment_id="seg:3", category="wind", severity=Severity.HIGH,
               window_start=NOW, window_end=NOW, provenance=src)  # type: ignore[arg-type]
