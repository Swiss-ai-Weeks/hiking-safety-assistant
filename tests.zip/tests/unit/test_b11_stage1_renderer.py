from datetime import timedelta
from pathlib import Path

from hsa.adapters.warnings import UnavailableWarnings
from hsa.fusion.engine import FusionEngine
from hsa.gate.renderer import Renderer
from hsa.gate.stage1 import STALE_CONFIDENCE_CAP, apply_stage1
from hsa.rules.loader import load_catalogue
from tests.fakes.scenario import RUN, demo_route, plan, snapshot

ROOT = Path(__file__).resolve().parents[2]
CAT = load_catalogue(ROOT / "src/hsa/rules/rules", ROOT / "templates")


def _res(now_offset_h=1, gust=55.0):
    route, p = demo_route(), plan()
    snap = snapshot(route, p, gust_by_segment={2: gust})
    return FusionEngine(CAT).assess(route, p, snap, UnavailableWarnings().fetch("x"), now=RUN + timedelta(hours=now_offset_h)), snap


def test_INV4_stale_forecast_caps_confidence_and_attaches_label():
    res, snap = _res(now_offset_h=8)
    framed = apply_stage1(res.assessment, snap, now=RUN + timedelta(hours=8))
    assert framed.assessment.stale is True
    assert framed.assessment.confidence <= STALE_CONFIDENCE_CAP
    assert framed.stale_label and "7 h" in framed.stale_label or "8 h" in framed.stale_label


def test_INV5_low_confidence_sets_cautionary_framing():
    res, snap = _res(now_offset_h=8)
    framed = apply_stage1(res.assessment, snap, now=RUN + timedelta(hours=8))
    assert framed.assessment.cautionary is True
    fresh, snap2 = _res(now_offset_h=1)
    assert apply_stage1(fresh.assessment, snap2, now=RUN + timedelta(hours=1)).assessment.cautionary is False


def test_renderer_produces_en_and_de_sentence_for_seed_rule_with_slots_filled():
    res, _ = _res()
    h = [x for x in res.assessment.hazards if x.provenance.rule_id == "WIND-EXP-02"][0]
    en = Renderer(CAT).render_hazard(h, "en")
    de = Renderer(CAT).render_hazard(h, "de")
    assert "{" not in en.title + en.body and "{" not in de.title + de.body
    assert "55" in en.body and "Böen" in de.title
    assert en.provenance.startswith("Rule WIND-EXP-02 v3") and en.fallback_notice is None


def test_renderer_falls_back_to_en_with_notice_when_de_template_missing():
    res, _ = _res()
    h = res.assessment.hazards[0]
    r = Renderer(CAT)
    r.cat.templates.pop((h.provenance.rule_id, "de"))
    de = r.render_hazard(h, "de")
    assert de.lang == "en" and de.fallback_notice
