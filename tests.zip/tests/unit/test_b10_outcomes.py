from datetime import timedelta
from pathlib import Path

from hsa.adapters.interfaces import Unresolved
from hsa.adapters.warnings import UnavailableWarnings
from hsa.domain.models import Unknown
from hsa.domain.outcome import Outcome, classify
from hsa.fusion.engine import FusionEngine
from hsa.rules.loader import load_catalogue
from tests.fakes.scenario import RUN, demo_route, plan, snapshot

ROOT = Path(__file__).resolve().parents[2]
CAT = load_catalogue(ROOT / "src/hsa/rules/rules", ROOT / "templates")
NOW = RUN + timedelta(hours=1)


def run(route, p, snap):
    return FusionEngine(CAT).assess(route, p, snap, UnavailableWarnings().fetch("x"), now=NOW)


def test_not_assessable_when_weather_unavailable():
    o = classify(route=demo_route(), plan=plan(), fusion=None, snapshot=None, fatal=None)
    assert o.outcome == Outcome.NOT_ASSESSABLE and "weather" in o.reason.lower()


def test_not_assessable_when_route_unresolved():
    o = classify(route=Unresolved(reason="no such route"), plan=plan(), fusion=None, snapshot=None, fatal=None)
    assert o.outcome == Outcome.NOT_ASSESSABLE and "route" in o.reason.lower()


def test_partially_assessed_when_one_rule_on_one_segment_lacks_input():
    route, p = demo_route(), plan()
    route.segments[1].exposure = Unknown()  # wind rules need exposure on segment 1
    snap = snapshot(route, p)
    res = run(route, p, snap)
    o = classify(route=route, plan=p, fusion=res, snapshot=snap, fatal=None)
    assert o.outcome == Outcome.PARTIALLY_ASSESSED
    assert any(seg == route.segments[1].id and "exposure" in missing for seg, rule, missing in o.not_evaluated)


def test_assessed_when_all_applicable_rules_evaluated():
    route, p = demo_route(), plan()
    snap = snapshot(route, p)
    o = classify(route=route, plan=p, fusion=run(route, p, snap), snapshot=snap, fatal=None)
    assert o.outcome == Outcome.ASSESSED and o.not_evaluated == []


def test_missing_capability_uses_conservative_default_and_stays_assessed():
    route, p = demo_route(), plan(capability=None)
    snap = snapshot(route, p)
    o = classify(route=route, plan=p, fusion=run(route, p, snap), snapshot=snap, fatal=None)
    assert o.outcome == Outcome.ASSESSED and o.assumed_capability is not None and o.assumed_capability_note


def test_empty_hazard_list_only_reported_under_assessed():
    route, p = demo_route(), plan()
    snap = snapshot(route, p)
    assessed = classify(route=route, plan=p, fusion=run(route, p, snap), snapshot=snap, fatal=None)
    assert assessed.show_nothing_flagged is True
    route.segments[1].exposure = Unknown()
    snap2 = snapshot(route, p)
    partial = classify(route=route, plan=p, fusion=run(route, p, snap2), snapshot=snap2, fatal=None)
    assert partial.show_nothing_flagged is False


def test_unknown_unused_attribute_goes_to_not_available_list_not_outcome():
    route, p = demo_route(), plan()
    route.segments[0].fixed_cables = Unknown()  # no catalogue rule consumes fixed_cables
    snap = snapshot(route, p)
    o = classify(route=route, plan=p, fusion=run(route, p, snap), snapshot=snap, fatal=None)
    assert o.outcome == Outcome.ASSESSED
    assert any("fixed_cables" in item for item in o.not_available)


def test_fatal_post_condition_is_not_assessable():
    route, p = demo_route(), plan()
    snap = snapshot(route, p)
    o = classify(route=route, plan=p, fusion=run(route, p, snap), snapshot=snap, fatal="INV-3: ghost")
    assert o.outcome == Outcome.NOT_ASSESSABLE and "INV-3" in o.reason
