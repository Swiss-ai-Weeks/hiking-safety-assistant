from datetime import datetime, timedelta, timezone

from hsa.adapters.meteoswiss import MeteoSwissClient


class FakeHttp:
    """Two pages of 100 items for one run; range query returns two runs; no sortby support."""

    def __init__(self):
        self.calls = []

    def post(self, url, json):
        self.calls.append(json)
        ref = json.get("forecast:reference_datetime", "")
        def item(r, h):
            return {"id": f"{r}-{h}", "properties": {"forecast:reference_datetime": r, "forecast:horizon": f"P0DT{h:02d}H00M00S" if h < 24 else f"P{h//24}DT{h%24:02d}H00M00S",
                    "forecast:variable": "T_2M", "forecast:perturbed": False}, "assets": {"a": {"href": f"https://x/{r}/{h}"}}}
        class R:
            def __init__(s, d): s.d = d
            def raise_for_status(s): pass
            def json(s): return s.d
        if "/" in ref:  # range query
            return R({"features": [item("2026-09-13T18:00:00Z", 0), item("2026-09-14T06:00:00Z", 0)], "links": []})
        if json.get("_page") == 2:
            return R({"features": [item(ref, h) for h in range(100, 121)], "links": []})
        return R({"features": [item(ref, h) for h in range(0, 100)],
                  "links": [{"rel": "next", "href": "https://data.geo.admin.ch/api/stac/v1/search", "method": "POST", "body": {**json, "_page": 2}, "merge": True}]})


def test_latest_run_uses_range_filter_then_pages_through_all_horizons():
    c = MeteoSwissClient.__new__(MeteoSwissClient)
    c._http = FakeHttp()
    ref, items = c.latest_run("ch.meteoschweiz.ogd-forecasting-icon-ch2", "T_2M", now=datetime(2026, 9, 14, 17, 0, tzinfo=timezone.utc))
    assert ref == datetime(2026, 9, 14, 6, 0, tzinfo=timezone.utc)
    assert len(items) == 121 and max(i["horizon"] for i in items) == timedelta(hours=120)
    assert any("/" in call.get("forecast:reference_datetime", "") for call in c._http.calls)
