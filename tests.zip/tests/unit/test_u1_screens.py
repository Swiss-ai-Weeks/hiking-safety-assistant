"""U1: the seven mock-up screens render from fixture data with the mandated copy rules."""
import re

import pytest
from fastapi.testclient import TestClient

from hsa.api.app import app

client = TestClient(app)
FORBIDDEN = re.compile(r"\b(safe|go ahead|good to go|clear to)\b", re.I)


@pytest.mark.parametrize(
    "path,must_contain",
    [
        ("/", ["Plan a hike", "Where are you going, and when?", "Check conditions"]),
        ("/assess", ["Assessed", "Most exposed point", "Along the hike", "Flagged",
                     "What we can't see", "Ways to keep the day", "Set up the day"]),
        ("/assess?outcome=not_assessable", ["Not assessable", "We can't assess this hike right now.",
                                            "Try again"]),
        ("/map", ["Route map", "Segments", "Locate me"]),
        ("/preflight", ["Before you go", "Turnaround rule", "Accept plan", "Start hike"]),
        ("/field", ["Offline", "turnaround", "Emergency 1414", "Show descent"]),
        ("/share", ["We turn around if", "Watch for", "Not checked", "Share card"]),
    ],
)
def test_screen_renders_required_copy(path, must_contain):
    r = client.get(path)
    assert r.status_code == 200
    for s in must_contain:
        assert s in r.text, f"{path} missing {s!r}"


@pytest.mark.parametrize("path", ["/", "/assess", "/assess?outcome=not_assessable", "/map",
                                  "/preflight", "/field", "/share"])
def test_no_verdict_words_in_body_copy(path):
    body = client.get(path).text
    assert not FORBIDDEN.search(body), FORBIDDEN.search(body)


def test_assessment_carries_disclaimer_and_channels():
    body = client.get("/assess").text
    assert "Decision support, not a go/no-go" in body
    assert "1414" in body and "112" in body


def test_not_assessable_has_no_primary_action_and_no_hazards():
    body = client.get("/assess?outcome=not_assessable").text
    assert "Set up the day" not in body
    assert "Flagged" not in body


def test_static_css_served():
    assert client.get("/static/app.css").status_code == 200
