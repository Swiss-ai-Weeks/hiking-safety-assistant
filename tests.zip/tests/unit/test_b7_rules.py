from pathlib import Path

import pytest

from hsa.domain.models import Unknown
from hsa.rules.loader import CatalogueError, load_catalogue
from hsa.rules.schema import HazardRule, evaluate_rule

ROOT = Path(__file__).resolve().parents[2]


def test_rule_requires_id_version_inputs_condition_severity_justification_basis():
    with pytest.raises(Exception):
        HazardRule(id="X", version=1, inputs=["gust_kmh"], condition="gust_kmh >= 50", severity="high",
                   justification="", basis="SAC", category="wind")  # empty justification rejected


def test_catalogue_loads_seed_rules_with_en_and_de_templates():
    cat = load_catalogue(ROOT / "src/hsa/rules/rules", ROOT / "templates", languages=("en", "de"))
    ids = {r.id for r in cat.rules}
    assert {"WIND-EXP-02", "PRECIP-DESC-01"} <= ids
    assert cat.template("WIND-EXP-02", "de") and cat.template("WIND-EXP-02", "en")


def test_loader_rejects_rule_missing_template_for_enabled_language(tmp_path):
    rules = tmp_path / "rules"; rules.mkdir()
    (rules / "r.yaml").write_text(
        "id: TEST-01\nversion: 1\ncategory: wind\ninputs: [gust_kmh]\ncondition: 'gust_kmh >= 50'\n"
        "severity: high\njustification: test\nbasis: test\n")
    tpl = tmp_path / "templates"; (tpl / "en").mkdir(parents=True); (tpl / "en" / "TEST-01.txt").write_text("Gusts {gust_kmh} km/h.")
    with pytest.raises(CatalogueError) as e:
        load_catalogue(rules, tpl, languages=("en", "de"))
    assert "TEST-01" in str(e.value) and "de" in str(e.value)


def test_rule_with_missing_required_input_returns_not_evaluated():
    rule = HazardRule(id="T", version=1, category="wind", inputs=["gust_kmh", "exposure"],
                      condition="gust_kmh >= 50 and exposure", severity="high", justification="j", basis="b")
    res = evaluate_rule(rule, {"gust_kmh": 55.0, "exposure": Unknown()})
    assert res.status == "not_evaluated" and "exposure" in res.missing
    fired = evaluate_rule(rule, {"gust_kmh": 55.0, "exposure": True})
    assert fired.status == "fired"
    quiet = evaluate_rule(rule, {"gust_kmh": 20.0, "exposure": True})
    assert quiet.status == "not_fired"
