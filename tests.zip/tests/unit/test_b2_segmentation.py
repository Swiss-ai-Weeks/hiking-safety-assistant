from datetime import datetime, timezone

from hsa.domain.models import Unknown
from hsa.geo.segment import split_route
from hsa.geo.traversal import traversal_windows

# 6 km synthetic east-west line with a 400 m climb between km 2 and km 3.5
LINE = [(46.50, 7.70 + i * 0.0131) for i in range(7)]  # ~1 km per step at 46.5°N
PROFILE = [1200, 1200, 1200, 1400, 1600, 1600, 1600]  # altitude at each vertex


def test_polyline_with_profile_splits_at_distance_or_elevation_threshold():
    segs = split_route("r1", LINE, PROFILE, max_len_m=2500, max_climb_m=250)
    assert 3 <= len(segs) <= 5
    assert segs[0].coords[0] == LINE[0] and segs[-1].coords[-1] == LINE[-1]
    assert abs(sum(s.length_m for s in segs) - 6000) < 300
    assert sum(s.ascent_m for s in segs) == 400
    assert all(s.length_m <= 2500 + 1 for s in segs)
    assert all(s.ascent_m <= 250 + 1e-6 or len(s.coords) == 2 for s in segs)


def test_traversal_windows_are_contiguous_and_monotonic():
    segs = split_route("r1", LINE, PROFILE, max_len_m=2500, max_climb_m=250)
    start = datetime(2026, 9, 19, 8, 0, tzinfo=timezone.utc)
    wins = traversal_windows(segs, start, pace_factor=1.0)
    assert wins[0].start == start
    for a, b in zip(wins, wins[1:]):
        assert a.end == b.start
        assert a.end > a.start
    total_h = (wins[-1].end - start).total_seconds() / 3600
    assert 1.5 < total_h < 4.0  # 6 km + 400 m climb, reference formula


def test_segment_carries_terrain_attribute_placeholders_as_unknown():
    seg = split_route("r1", LINE, PROFILE)[0]
    assert isinstance(seg.grade, Unknown)
    assert isinstance(seg.exposure, Unknown)
    assert seg.exposure is not None and seg.exposure is not False
