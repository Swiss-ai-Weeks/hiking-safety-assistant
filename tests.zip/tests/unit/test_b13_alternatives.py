from datetime import timedelta
from pathlib import Path

from hsa.adapters.warnings import UnavailableWarnings
from hsa.domain.models import GradeRange, Unknown
from hsa.fusion.alternatives import eligibility_limit, propose
from hsa.fusion.engine import FusionEngine
from hsa.rules.loader import load_catalogue
from tests.fakes.scenario import RUN, demo_route, plan, snapshot

ROOT = Path(__file__).resolve().parents[2]
CAT = load_catalogue(ROOT / "src/hsa/rules/rules", ROOT / "templates")
NOW = RUN + timedelta(hours=1)
ENG = FusionEngine(CAT)


def gust_field(ridge_by_hour):
    """Weather provider: ridge gusts depend on the hour the hiker is on the ridge (segment 2)."""
    def provider(route, p):
        from hsa.geo.traversal import traversal_windows
        w = traversal_windows(route.segments, p.start_time, p.pace_factor)[2]
        g = ridge_by_hour(w.start.hour)
        return snapshot(route, p, gust_by_segment={2: g})
    return provider


def test_shifted_start_that_removes_hazard_is_offered_as_mitigation():
    route, p = demo_route(), plan()
    provider = gust_field(lambda h: 55.0 if h >= 11 else 30.0)
    base = ENG.assess(route, p, provider(route, p), UnavailableWarnings().fetch("x"), now=NOW)
    out = propose(base, route, p, ENG, provider, candidates=[], now=NOW)
    starts = [m for m in out.recommendations if m.provenance.rule_id == "MIT-START-01"]
    assert starts and starts[0].justifies == [base.assessment.hazards[0].id]
    from hsa.fusion.engine import ZURICH
    assert starts[0].slots["new_start"] < p.start_time.astimezone(ZURICH).strftime("%H:%M")


def test_shifted_start_that_adds_equal_hazard_is_not_offered():
    route, p = demo_route(), plan()
    provider = gust_field(lambda h: 55.0)  # windy all day: shifting start changes nothing
    base = ENG.assess(route, p, provider(route, p), UnavailableWarnings().fetch("x"), now=NOW)
    out = propose(base, route, p, ENG, provider, candidates=[], now=NOW)
    assert not [m for m in out.recommendations if m.provenance.rule_id == "MIT-START-01"]
    assert out.none_found_reason


def test_candidate_with_grade_upper_bound_above_L_is_ineligible():
    route, p = demo_route(), plan(capability=None)
    assert eligibility_limit(route, p) == 3  # plan grade T2–T3, no stated capability -> upper bound 3
    harder = demo_route(); harder.id = "alt:hard"; harder.grade = GradeRange(low=4, high=6)
    easier = demo_route(); easier.id = "alt:easy"; easier.grade = GradeRange(low=1, high=1, exact=True)
    for s in easier.segments:
        s.exposure = False
    provider = gust_field(lambda h: 55.0)
    base = ENG.assess(route, p, provider(route, p), UnavailableWarnings().fetch("x"), now=NOW)
    out = propose(base, route, p, ENG, provider, candidates=[harder, easier], now=NOW)
    alts = [r for r in out.recommendations if r.kind == "alternative"]
    assert [a.slots["route_id"] for a in alts] == ["alt:easy"]
    assert any("alt:hard" in x for x in out.ineligible)


def test_unknown_grade_candidate_never_auto_proposed():
    route, p = demo_route(), plan()
    unk = demo_route(); unk.id = "alt:unk"; unk.grade = Unknown()
    for s in unk.segments:
        s.exposure = False
    provider = gust_field(lambda h: 55.0)
    base = ENG.assess(route, p, provider(route, p), UnavailableWarnings().fetch("x"), now=NOW)
    out = propose(base, route, p, ENG, provider, candidates=[unk], now=NOW)
    assert not [r for r in out.recommendations if r.kind == "alternative"]
    assert any("alt:unk" in x and "unknown grade" in x for x in out.ineligible)


def test_candidate_gets_own_snapshot_and_plan():
    route, p = demo_route(), plan()
    calls = []
    def provider(r, pl):
        calls.append((r.id, pl.start_time))
        return snapshot(r, pl, gust_by_segment={2: 55.0 if r.id == route.id else 10.0})
    easier = demo_route(); easier.id = "alt:easy"; easier.grade = GradeRange(low=2, high=2, exact=True)
    base = ENG.assess(route, p, provider(route, p), UnavailableWarnings().fetch("x"), now=NOW)
    propose(base, route, p, ENG, provider, candidates=[easier], now=NOW)
    assert any(rid == "alt:easy" for rid, _ in calls)


def test_no_qualifying_option_yields_explicit_none_found_with_channels():
    route, p = demo_route(), plan()
    provider = gust_field(lambda h: 55.0)
    base = ENG.assess(route, p, provider(route, p), UnavailableWarnings().fetch("x"), now=NOW)
    out = propose(base, route, p, ENG, provider, candidates=[], now=NOW)
    # a turnaround rule is always offerable (the hazard is simply not reached); starts and alternatives are not
    assert not [r for r in out.recommendations if r.provenance.rule_id in ("MIT-START-01", "ALT-ROUTE-01")]
    assert out.none_found_reason and "MeteoSwiss" in out.none_found_reason
