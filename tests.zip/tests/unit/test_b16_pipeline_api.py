import time

from fastapi.testclient import TestClient

from hsa.api.app import app
from hsa.api.pipeline import Pipeline, demo_pipeline

client = TestClient(app)
Q = "route=Oeschinensee+%E2%86%92+Bl%C3%BCemlisalph%C3%BCtte&date=2026-09-19&start=07:30"


def test_assess_renders_real_outcome_line_crux_and_rule_provenance_footnote():
    r = client.get(f"/assess?{Q}")
    assert r.status_code == 200
    assert "Assessed" in r.text and "Most exposed point" in r.text
    assert "Rule WIND-EXP-02 v3" in r.text  # provenance footnote only; rule ids never in body copy
    assert "Hohtürli" in r.text  # place from the resolved route, not fixture copy


def test_response_contains_disclaimer_block_and_warnings_disclosure():
    body = client.get(f"/assess?{Q}").text
    assert "Decision support, not a go/no-go" in body and "1414" in body
    assert "Official weather warnings could not be checked" in body


def test_assessment_path_under_budget_with_fakes():
    t = time.perf_counter()
    view = demo_pipeline().assess("Oeschinensee → Blüemlisalphütte", "2026-09-19", "07:30", lang="en")
    assert time.perf_counter() - t < 2.0  # regression guard on the fake-backed path, not a latency proof
    assert view["outcome"] == "assessed" and view["hazards"]


def test_language_switch_to_de_renders_de_templates():
    body = client.get(f"/assess?{Q}&lang=de").text
    assert "Böen" in body and "Entscheidungshilfe" in body


def test_unknown_route_is_not_assessable_with_reason_and_no_primary_action():
    body = client.get("/assess?route=Nowhere+Ridge&date=2026-09-19&start=07:30").text
    assert "Not assessable" in body and "official network" in body
    assert "Set up the day" not in body and "Flagged" not in body


def test_mitigation_and_turnaround_come_from_fusion_not_fixture():
    view = demo_pipeline().assess("Oeschinensee → Blüemlisalphütte", "2026-09-19", "07:30", lang="en")
    kinds = {m["rule_id"] for m in view["mitigations"]}
    assert "MIT-TURN-01" in kinds
    assert view["plan"]["turnaround_time"] and view["plan"]["turnaround"]


def test_downstream_screens_use_the_same_assessment():
    for path in ("/preflight", "/field", "/share", "/map"):
        r = client.get(f"{path}?{Q}")
        assert r.status_code == 200 and "Hohtürli" in r.text
