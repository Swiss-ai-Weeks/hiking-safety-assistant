from hsa.api.pipeline import demo_pipeline
from hsa.domain.models import Unknown


def test_not_evaluated_cards_are_grouped_per_leg_with_rules_listed():
    p = demo_pipeline()
    route = p.routes.resolve_by_name("Oeschinensee → Blüemlisalphütte")
    route.segments[0].exposure = Unknown()
    p.routes.resolve_by_name = lambda name: route  # inject the modified route
    v = p.assess("Oeschinensee → Blüemlisalphütte", "2026-09-19", "07:30", lang="en")
    assert v["outcome"] == "partially_assessed"
    groups = v["not_evaluated"]
    assert len(groups) == 1 and groups[0]["segment"] == route.segments[0].name
    assert set(groups[0]["rules"]) == {"THUNDER-01", "WIND-EXP-01", "WIND-EXP-02"} and groups[0]["missing"] == ["exposure"]
