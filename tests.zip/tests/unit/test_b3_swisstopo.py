from hsa.adapters.interfaces import Unresolved
from hsa.adapters.swisstopo import trail_category_to_grade
from hsa.domain.models import GradeRange, Route
from tests.fakes.swisstopo import FakeSwisstopo


def test_resolve_route_by_name_returns_route_with_geometry_and_grade_range():
    r = FakeSwisstopo().resolve_by_name("Oeschinensee → Blüemlisalphütte")
    assert isinstance(r, Route)
    assert len(r.coords) >= 2 and len(r.segments) >= 3
    assert isinstance(r.grade, GradeRange) and r.grade.label() == "T2–T3"
    assert r.provenance is not None and r.provenance.source.startswith("fixture")


def test_resolve_route_by_start_end_returns_network_route_or_unresolved():
    f = FakeSwisstopo()
    assert isinstance(f.resolve_by_points((46.4985, 7.7275), (46.4935, 7.7755)), Route)
    u = f.resolve_by_points((47.0, 8.0), (47.1, 8.1))
    assert isinstance(u, Unresolved) and u.reason


def test_unknown_name_yields_unresolved_not_exception():
    u = FakeSwisstopo().resolve_by_name("Nowhere Ridge")
    assert isinstance(u, Unresolved)


def test_trail_category_maps_to_grade_range():
    assert trail_category_to_grade("Wanderweg").label() == "T1"
    assert trail_category_to_grade("Bergwanderweg").label() == "T2–T3"
    assert trail_category_to_grade("Alpinwanderweg").label() == "T4–T6"
    assert trail_category_to_grade("something else") is None
