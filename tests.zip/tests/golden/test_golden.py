import json
from pathlib import Path

import yaml

from hsa.api.pipeline import demo_pipeline
from hsa.eval.harness import score_cases
from tests.fakes.anthropic import Block, FakeAnthropic, Resp

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def scripted_for(case):
    blocks = [Block("tool_use", id=f"t{i}", name=n, input={"query": case["question"]} if n in ("resolve_route", "lookup_corpus")
                    else {"route_id": "r", "date": "2026-09-19", "start_time": "07:30", "pace_factor": None, "capability_grade": None} if n == "assess_plan"
                    else {"assessment_id": "ra:1"}) for i, n in enumerate(case["expect_tools"])]
    return [Resp(blocks, "tool_use"),
            Resp([Block("tool_use", id="tp", name="select_phrases", input={"ids": case["expect_phrases_any"][:1]})], "tool_use"),
            Resp([Block("text", text="ok")], "end_turn")]


def test_harness_scores_three_golden_cases_for_decomposition_and_excerpt_relevance():
    cases = yaml.safe_load((HERE / "cases.yaml").read_text())
    report = score_cases(cases, client_factory=lambda case: FakeAnthropic(scripted_for(case)))
    assert report["n"] == 3 and report["decomposition_ok"] == 3 and report["phrase_ok"] == 3
    assert report["excerpt_ok"] == 1 and report["discarded_text_blocks"] >= 3
    assert report["free_text_reached_user"] == 0


def test_golden_planning_scenario_matches_snapshot():
    """Rendered blocks for the demo scenario, EN and DE. Update the snapshot deliberately, never by accident."""
    p = demo_pipeline()
    out = {}
    for lang in ("en", "de"):
        v = p.assess("Oeschinensee → Blüemlisalphütte", "2026-09-19", "07:30", lang=lang)
        out[lang] = {"outcome": v["outcome"], "crux": v["crux"], "hazards": [{k: h[k] for k in ("sev", "title", "body", "provenance")} for h in v["hazards"]],
                     "nothing_flagged": v["nothing_flagged"], "cannot_see": v["cannot_see"],
                     "mitigations": [{k: m[k] for k in ("title", "body", "rule_id")} for m in v["mitigations"]],
                     "alternatives": [{k: a[k] for k in ("title", "body", "rule_id")} for a in v["alternatives"]],
                     "plan": v["plan"], "disclaimer": v["disclaimer"], "timeline": [{k: t.get(k) for k in ("time", "place", "sev")} for t in v["timeline"]]}
    snap = HERE / "golden_assessment.json"
    if not snap.exists():
        snap.write_text(json.dumps(out, ensure_ascii=False, indent=1, default=str))
        raise AssertionError("golden snapshot written for the first time; re-run to compare")
    assert json.loads(snap.read_text()) == json.loads(json.dumps(out, ensure_ascii=False, default=str))
