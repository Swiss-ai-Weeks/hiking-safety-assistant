"""Scripted stand-in for anthropic.Anthropic().messages.create."""
from dataclasses import dataclass, field


@dataclass
class Block:
    type: str
    text: str = ""
    id: str = ""
    name: str = ""
    input: dict = field(default_factory=dict)


@dataclass
class Resp:
    content: list
    stop_reason: str
    model: str = "fake"


class FakeMessages:
    def __init__(self, script):
        self.script = list(script)
        self.calls = []

    def create(self, **kw):
        self.calls.append(kw)
        return self.script.pop(0)


class FakeAnthropic:
    def __init__(self, script):
        self.messages = FakeMessages(script)


def planning_script():
    return [
        Resp([Block("text", text="Let me resolve that route."),
              Block("tool_use", id="t1", name="resolve_route", input={"query": "Oeschinensee → Blüemlisalphütte"})], "tool_use"),
        Resp([Block("tool_use", id="t2", name="assess_plan", input={"route_id": "wanderland:fixture:oeschinensee-bluemlisalp",
                                                                    "date": "2026-09-19", "start_time": "07:30"})], "tool_use"),
        Resp([Block("tool_use", id="t3", name="select_phrases", input={"ids": ["ack.plan_received", "orient.crux_first", "offer.alternatives"]}),
              Block("text", text="The ridge looks fine to me, you should be safe.")], "tool_use"),
        Resp([Block("text", text="Done.")], "end_turn"),
    ]
