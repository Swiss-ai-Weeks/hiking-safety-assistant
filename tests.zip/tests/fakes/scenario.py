"""Shared fixture builder: the demo route with a controllable weather field."""
from datetime import datetime, timedelta, timezone

from hsa.domain.models import HikePlan, WeatherCondition
from hsa.domain.provenance import SourceProvenance
from hsa.geo.traversal import traversal_windows
from hsa.weather.snapshot import SnapshotKey, WeatherSnapshot
from tests.fakes.swisstopo import FakeSwisstopo

RUN = datetime(2026, 9, 19, 6, 0, tzinfo=timezone.utc)
START = datetime(2026, 9, 19, 7, 30, tzinfo=timezone.utc)


def demo_route():
    r = FakeSwisstopo().resolve_by_name("Oeschinensee → Blüemlisalphütte")
    for s in r.segments:
        s.exposure = s.index == 2  # the ridge segment
        s.fixed_cables = s.index == 2
    return r


def plan(start=START, pace=1.25, capability=None):
    return HikePlan(route_id="wanderland:fixture:oeschinensee-bluemlisalp", date=start, start_time=start,
                    pace_factor=pace, capability_grade=capability)


def snapshot(route, p, gust_by_segment=None, precip_by_segment=None, fetched=None, run=RUN, temp=4.0):
    """One condition per segment per traversal hour; gusts and precipitation controllable per segment."""
    wins = traversal_windows(route.segments, p.start_time, p.pace_factor)
    conds = []
    for seg, w in zip(route.segments, wins):
        t = w.start.replace(minute=0)
        while t <= w.end:
            g = (gust_by_segment or {}).get(seg.index, 20.0)
            pr = (precip_by_segment or {}).get(seg.index, 0.0)
            conds.append(WeatherCondition(
                id=f"wc:{seg.index}:{t.hour}", segment_id=seg.id, valid_at=t, temperature_c=temp, gust_kmh=g,
                precipitation_mm=pr, cloud_base_m=3200.0, freezing_level_m=2900.0, cape_jkg=100.0,
                provenance=SourceProvenance(source="meteoswiss:icon-ch1", observed_at=run, confidence=0.85)))
            t += timedelta(hours=1)
    key = SnapshotKey(route_id=route.id, hike_date=p.start_time.date(), start_hour=p.start_time.hour,
                      pace_factor=p.pace_factor, forecast_window="ch1")
    return WeatherSnapshot(key=key, fetched_at=fetched or (run + timedelta(minutes=40)), run_time=run, conditions=conds)
