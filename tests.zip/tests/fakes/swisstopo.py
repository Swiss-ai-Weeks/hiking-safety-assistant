import json
from pathlib import Path

from hsa.adapters.interfaces import RouteSource, Unresolved
from hsa.adapters.swisstopo import route_from_record

FIX = Path(__file__).resolve().parents[1] / "fixtures" / "swisstopo_route_oeschinensee.json"
LOOP = FIX.with_name("swisstopo_route_oeschinensee_loop.json")


class FakeSwisstopo(RouteSource):
    def __init__(self):
        self.record = json.loads(FIX.read_text())
        self.loop = json.loads(LOOP.read_text())

    def resolve_by_name(self, name: str):
        if "loop" in name.lower():
            return route_from_record(self.loop)
        if name.lower().startswith("oeschinensee"):
            return route_from_record(self.record)
        return Unresolved(reason=f"no official route named {name!r}")

    def resolve_by_points(self, start, end):
        if abs(start[0] - 46.4985) < 0.01 and abs(end[0] - 46.4935) < 0.01:
            return route_from_record(self.record)
        return Unresolved(reason="no official network route joins those points")

    def candidates_near(self, start, radius_m, limit):
        return [route_from_record(self.record), route_from_record(self.loop)]
