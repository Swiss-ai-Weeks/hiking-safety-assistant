import pytest

from hsa.adapters.swisstopo import SwisstopoClient


@pytest.mark.live
def test_profile_service_returns_dist_and_alts():
    c = SwisstopoClient()
    pts = c.profile([(46.4985, 7.7275), (46.4940, 7.7740)], nb_points=20)
    assert len(pts) >= 10 and pts[-1]["dist"] > 3000 and 1400 < pts[0]["alt"] < 1800


@pytest.mark.live
def test_identify_hiking_network_near_oeschinensee():
    c = SwisstopoClient()
    feats = c.identify_trails((46.4985, 7.7275))
    assert feats, "expected swissTLM3D hiking trail features near Oeschinensee"


@pytest.mark.live
def test_find_wanderland_by_title_resolves_via_alpina_stage_with_grade_range():
    c = SwisstopoClient()
    r = c.resolve_by_name("Via Alpina (Griesalp - Kandersteg)")
    assert hasattr(r, "segments"), getattr(r, "reason", r)
    assert len(r.segments) >= 3 and r.grade is not None


@pytest.mark.live
def test_resolve_by_points_oeschinensee_to_hohtuerli_finds_via_alpina():
    c = SwisstopoClient()
    r = c.resolve_by_points((46.4985, 7.7275), (46.4940, 7.7740))
    assert hasattr(r, "name") and "Via Alpina" in r.name, getattr(r, "reason", r)
