import pytest

from hsa.adapters.meteoswiss import MeteoSwissClient


@pytest.mark.live
def test_stac_search_returns_latest_ch1_assets():
    c = MeteoSwissClient()
    ref, items = c.latest_run("ch.meteoschweiz.ogd-forecasting-icon-ch1", "T_2M")
    assert ref is not None and len(items) >= 10
    assert all(i["variable"] == "T_2M" and not i["perturbed"] for i in items)
