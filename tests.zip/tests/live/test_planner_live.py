import os

import pytest

from hsa.planner.planner import Planner
from hsa.planner.session import SessionStore


@pytest.mark.live
def test_one_real_call_returns_tool_use():
    import anthropic

    if not (os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN")):
        pytest.skip("no Anthropic credential in environment")
    calls = []
    def execute(name, args):
        calls.append(name)
        return {"route_id": "wanderland:x", "name": "Via Alpina (Griesalp - Kandersteg)"} if name == "resolve_route" else {"assessment_id": "ra:1", "outcome": "assessed", "hazards": 1}
    p = Planner(anthropic.Anthropic(), execute, phrase_ids=["ack.plan_received", "orient.crux_first"], max_turns=3)
    out = p.plan("Can I hike from Griesalp to Kandersteg on Saturday, starting 07:30?", SessionStore().get("live"))
    assert "resolve_route" in calls or "assess_plan" in calls
    assert out.model
