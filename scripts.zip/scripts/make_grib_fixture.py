"""Write a small regular lat/lon GRIB2 fixture around Oeschinensee for one variable and value field."""
import sys
from pathlib import Path

import eccodes as ec


def write(path: Path, value_fn, ni=12, nj=12, lat0=46.45, lat1=46.55, lon0=7.68, lon1=7.82):
    h = ec.codes_grib_new_from_samples("regular_ll_sfc_grib2")
    ec.codes_set(h, "Ni", ni); ec.codes_set(h, "Nj", nj)
    ec.codes_set(h, "latitudeOfFirstGridPointInDegrees", lat1); ec.codes_set(h, "latitudeOfLastGridPointInDegrees", lat0)
    ec.codes_set(h, "longitudeOfFirstGridPointInDegrees", lon0); ec.codes_set(h, "longitudeOfLastGridPointInDegrees", lon1)
    ec.codes_set(h, "iDirectionIncrementInDegrees", (lon1 - lon0) / (ni - 1)); ec.codes_set(h, "jDirectionIncrementInDegrees", (lat1 - lat0) / (nj - 1))
    vals = []
    for j in range(nj):
        lat = lat1 - j * (lat1 - lat0) / (nj - 1)
        for i in range(ni):
            lon = lon0 + i * (lon1 - lon0) / (ni - 1)
            vals.append(value_fn(lat, lon))
    ec.codes_set_values(h, vals)
    with open(path, "wb") as f:
        ec.codes_write(h, f)
    ec.codes_release(h)


if __name__ == "__main__":
    out = Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)
    # T_2M in kelvin: 277 K (4 °C) everywhere; VMAX_10M in m/s: 16 m/s (57.6 km/h) east of 7.76, else 6 m/s
    write(out / "T_2M.grib2", lambda lat, lon: 277.15)
    write(out / "VMAX_10M.grib2", lambda lat, lon: 16.0 if lon > 7.76 else 6.0)
    write(out / "TOT_PREC.grib2", lambda lat, lon: 0.0)
    write(out / "HZEROCL.grib2", lambda lat, lon: 2900.0)
    print("fixture written to", out)
